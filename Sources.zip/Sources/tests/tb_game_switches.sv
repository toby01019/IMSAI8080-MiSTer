`timescale 1ns/1ps
module tb_game_switches;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,enabled=1;reg [10:0] key=0;wire [7:0] switches;
 imsai_game_switches dut(.*);
 task event_key(input pressed,input [7:0] scan);
 begin @(negedge clk);key={~key[10],pressed,1'b0,scan};
 repeat(3) @(negedge clk);end
 endtask
 initial begin
 repeat(3) @(negedge clk);reset=0;
 if(switches!==2) $fatal(1,"startup speed");
 event_key(1,8'h16);if(switches!==8'h82) $fatal(1,"left key");
 event_key(1,8'h16);if(switches!==8'h82) $fatal(1,"typematic retrigger");
 event_key(0,8'h16);event_key(1,8'h16);if(switches!==2) $fatal(1,"toggle off");
 event_key(1,8'h3e);if(switches!==3) $fatal(1,"right key");
 enabled=0;event_key(1,8'h1e);if(switches!==3) $fatal(1,"STOP input leak");
 $display("PASS: eight latched switches, left/right mapping, repeat suppression and STOP guard");
 $finish;
 end
endmodule
