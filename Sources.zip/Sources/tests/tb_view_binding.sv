`timescale 1ns/1ps
module tb_view_binding;
 reg clk_system=0;always #10 clk_system=~clk_system;
 reg machine_reset=1,external_reset=1,loaded=0,tx_write=0;reg [7:0]tx_data=0;reg [10:0]keyboard_event=0;
 wire tx_ready;wire [23:0]pixel_rgb;wire VGA_HS,VGA_VS,VGA_DE,CLK_VIDEO,CE_PIXEL;
 imsai_binding_harness dut(.*);
 task f7;
 begin @(negedge clk_system);keyboard_event={~keyboard_event[10],1'b1,1'b0,8'h83};
 repeat(4)@(negedge clk_system);keyboard_event={~keyboard_event[10],1'b0,1'b0,8'h83};
 repeat(4)@(negedge clk_system);end endtask
 initial begin
  repeat(4)@(negedge clk_system);external_reset=0;
  // CPU remains reset because there is no program. View control must be independent.
  force dut.x=0;force dut.y=480;force dut.pixel_enable=1;
  f7; if(!dut.front_view)$fatal(1,"zoom held in CPU no-ROM reset");
  f7; if(dut.front_view)$fatal(1,"return without ROM");
  external_reset=1;repeat(4)@(negedge clk_system);if(dut.front_view)$fatal(1,"master reset");
  $display("PASS: actual top-level view wiring allows F7 while CPU is held in no-ROM reset");$finish;
 end
endmodule
