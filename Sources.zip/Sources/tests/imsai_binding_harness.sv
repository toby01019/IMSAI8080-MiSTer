`timescale 1ns/1ps
module imsai_binding_harness(input wire clk_system,machine_reset,tx_write,loaded,external_reset,input wire [7:0]tx_data,
 input wire [10:0]keyboard_event,output wire tx_ready,output wire [23:0]pixel_rgb,
 output wire VGA_HS,VGA_VS,VGA_DE,CLK_VIDEO,CE_PIXEL);
 wire [7:0] VGA_R,VGA_G,VGA_B;
 assign pixel_rgb={VGA_R,VGA_G,VGA_B};
 wire game_mode=0,halted=0,stopped=1,panel_deposit=0;
 wire [15:0] panel_address=16'h8000,address=16'ha55a;
 wire [7:0] panel_data=8'ha5,panel_read_data=8'h42,bus_data=8'h42;
 wire [7:0] lamps=8'h81,switches=8'h42,cpu_status=8'ha3;
 wire interrupts_enabled=1,cpu_wait=0,cpu_hold=0;
 wire [1:0]edit_mode=0;
 wire [1:0]reset_pipe=0,buttons=0;wire [127:0]options=0;wire RESET=external_reset;
    // 640x480 raster: terminal and scaled original-style panel share one screen.
    reg pixel_enable=0;reg [9:0] x=0,y=0;
    reg [9:0] scaled_x=0,scaled_y=96;reg [1:0] scale_phase_x=0,scale_phase_y=0;
    always @(posedge clk_system) begin
      pixel_enable<=!pixel_enable;
      if(pixel_enable) begin
        if(x==799)begin
          x<=0;scaled_x<=0;scale_phase_x<=0;
          if(y==524)begin y<=0;scaled_y<=96;scale_phase_y<=0;end
          else begin
            y<=y+1'b1;
            if(y>=250 && y<448)begin
              scaled_y<=scaled_y+(scale_phase_y==2?2:1);
              scale_phase_y<=scale_phase_y==2?0:scale_phase_y+1'b1;
            end
          end
        end else begin
          x<=x+1'b1;
          if(x>=80 && x<560)begin
            scaled_x<=scaled_x+(scale_phase_x==2?2:1);
            scale_phase_x<=scale_phase_x==2?0:scale_phase_x+1'b1;
          end
        end
      end
    end
    assign CLK_VIDEO=clk_system;assign CE_PIXEL=pixel_enable;
    wire raw_hs=!(x>=656 && x<752),raw_vs=!(y>=490 && y<492),raw_de=x<640 && y<480;
    wire [9:0] term_x=x>=80 && x<560?x-10'd16:10'd1023;
    wire [9:0] term_y=y>=8 && y<200?y+10'd56:10'd511;
    wire terminal_pixel;
    imsai_terminal terminal(.clk(clk_system),.reset(machine_reset),
      .tx_write(tx_write),.tx_data(tx_data),.x(term_x),.y(term_y),
      .ready(tx_ready),.text_pixel(terminal_pixel));

    reg [15:0] shown_address=0,shown_panel_switches=0;
    reg [7:0] shown_data=0,shown_lamps=0,shown_switches=0,shown_status=0;
    reg shown_inte=0,shown_wait=0,shown_hold=0,shown_running=0,shown_stopped=0,shown_loaded=0;
    reg [1:0] shown_edit=0;
    reg [21:0] deposit_flash=0,reset_flash=0;
    always @(posedge clk_system) begin
      if(panel_deposit)deposit_flash<=3000000;else if(deposit_flash!=0)deposit_flash<=deposit_flash-1'b1;
      if(machine_reset)reset_flash<=3000000;else if(reset_flash!=0)reset_flash<=reset_flash-1'b1;
    end
    reg shown_deposit=0,shown_reset=0;
    always @(posedge clk_system)if(pixel_enable && x==0 && y==480)begin
      shown_address<=stopped?panel_address:address;shown_data<=stopped?panel_read_data:bus_data;
      shown_lamps<=lamps;shown_switches<=switches;shown_status<=cpu_status;
      shown_panel_switches<=stopped?(edit_mode==2?{panel_address[15:8],panel_data}:panel_address):{8'b0,switches};
      shown_inte<=interrupts_enabled;shown_wait<=cpu_wait;shown_hold<=cpu_hold;
      shown_running<=loaded && !halted && !stopped;shown_stopped<=stopped;shown_loaded<=loaded;shown_edit<=edit_mode;
      shown_deposit<=deposit_flash!=0;shown_reset<=reset_flash!=0;
    end
    wire front_view;
    imsai_view_select view_control(.clk(clk_system),.reset(reset_pipe[1] | RESET | options[0] | buttons[1]),.loaded(loaded),
      .game_mode(game_mode),.frame_end(pixel_enable && x==0 && y==480),
      .key(keyboard_event),.front_view(front_view));
    wire combined_panel=x>=80 && x<560 && y>=250 && y<448;
    wire [9:0] front_x=front_view?x:(combined_panel?scaled_x:10'd1023);
    wire [9:0] front_y=front_view?y:(combined_panel?scaled_y:10'd511);
    wire [23:0] front_rgb;
    imsai_front_video front_graphics(.clk(clk_system),.x(front_x),.y(front_y),
      .address_bits(shown_address),.switch_bits(shown_panel_switches),.input_bits(shown_switches),
      .data_bits(shown_data),.lamps(shown_lamps),.status_bits(shown_status),
      .inte(shown_inte),.running(shown_running),.cpu_wait(shown_wait),.cpu_hold(shown_hold),
      .stopped(shown_stopped),.loaded(shown_loaded),.edit_mode(shown_edit),
      .deposit_active(shown_deposit),.reset_active(shown_reset),.rgb(front_rgb));
    localparam [8*64-1:0] HELP="F1 RUN/STOP F2 ADDR F3 BYTE F4 WRITE F5+ F6- F7 ZOOM            ";
    localparam [8*64-1:0] LIMITS="STEP/POWER: DISPLAY ONLY  INPUT: F12 OR GAME KEYS 1-8           ";
    reg [7:0] label_char;reg [2:0] label_col;reg [3:0] label_row;integer ci;
    wire label_pixel;
    imsai_font labels(label_char,label_col,label_row,label_pixel);
    function [7:0] hex_char(input [3:0] n);hex_char=(n<10?8'd48:8'd55)+n;endfunction
    always @* begin
      label_char=32;label_col=0;label_row=0;ci=0;
      if(x>=64 && x<576)begin
        ci=(x-64)>>3;label_col=(x-64)%8;
        if(y>=464 && y<476)begin label_char=HELP[(63-ci)*8+:8];label_row=y-464;end
        if(y>=232 && y<244)begin label_char=LIMITS[(63-ci)*8+:8];label_row=y-232;end
        if(y>=208 && y<220)begin
          label_row=y-208;
          case(ci)
          0:label_char="M";1:label_char="E";2:label_char="M";
          4:label_char=hex_char(shown_address[15:12]);5:label_char=hex_char(shown_address[11:8]);
          6:label_char=hex_char(shown_address[7:4]);7:label_char=hex_char(shown_address[3:0]);
          9:label_char="=";11:label_char=hex_char(shown_data[7:4]);12:label_char=hex_char(shown_data[3:0]);
          16:label_char="W";17:label_char="R";18:label_char="I";19:label_char="T";20:label_char="E";
          22:label_char=hex_char(panel_data[7:4]);23:label_char=hex_char(panel_data[3:0]);
          27:label_char="I";28:label_char="N";30:label_char=hex_char(shown_switches[7:4]);31:label_char=hex_char(shown_switches[3:0]);
          36:label_char=loaded?"L":"N";37:label_char=loaded?"O":"O";38:label_char=loaded?"A":" ";39:label_char=loaded?"D":"R";
          40:label_char=loaded?"E":"O";41:label_char=loaded?"D":"M";
          46:label_char=stopped?"S":"R";47:label_char=stopped?"T":"U";48:label_char=stopped?"O":"N";49:label_char=stopped?"P":" ";
          default:label_char=32;
          endcase
        end
      end
    end
    reg [23:0] upper_color;
    always @* begin
      upper_color=24'h101418;
      if(x>=72 && x<568 && y<202)upper_color=24'h22343c;
      if(x>=80 && x<560 && y>=8 && y<200)upper_color=24'h081510;
      if(terminal_pixel)upper_color=24'h7ee8a0;
      if(label_pixel)upper_color=24'hd0d9df;
      if(!raw_de)upper_color=0;
    end
    reg [23:0] upper_q=0,upper_d=0;
    reg [1:0] hs_pipe=3,vs_pipe=3,de_pipe=0,panel_pipe=0;
    always @(posedge clk_system)begin
      upper_q<=upper_color;upper_d<=upper_q;
      hs_pipe<={hs_pipe[0],raw_hs};vs_pipe<={vs_pipe[0],raw_vs};de_pipe<={de_pipe[0],raw_de};
      panel_pipe<={panel_pipe[0],combined_panel};
    end
    assign VGA_HS=hs_pipe[1];assign VGA_VS=vs_pipe[1];assign VGA_DE=de_pipe[1];
    assign {VGA_R,VGA_G,VGA_B}=de_pipe[1]?((front_view||panel_pipe[1])?front_rgb:upper_d):24'b0;
endmodule
