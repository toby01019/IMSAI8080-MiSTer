`timescale 1ns/1ps
module tb_demo;
 wire interrupts_enabled,cpu_wait,cpu_hold;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,loader_write=0;
 reg [15:0] loader_address=0;reg [7:0] loader_data=0,switches=0;
 wire [7:0] lamps,bus_data,status;wire [15:0] address;wire halted;
    reg stop_requested=0,panel_deposit=0;
    reg [15:0] panel_address=0;
    reg [7:0] panel_data=0;
    wire stopped;wire [7:0] panel_read_data;
 reg [7:0] terminal_rx_data=65;reg terminal_rx_valid=0;
 wire terminal_rx_read,terminal_tx_write;wire [7:0] terminal_tx_data;
 wire terminal_tx_ready;
 reg [9:0] x=64,y=64;wire text_pixel;
 imsai_machine machine(.*);
 imsai_terminal terminal(.clk(clk),.reset(reset),
 .tx_write(terminal_tx_write),.tx_data(terminal_tx_data),
 .x(x),.y(y),.ready(terminal_tx_ready),.text_pixel(text_pixel));
 reg [7:0] program_bytes[0:165];
 reg [4095:0] rom_file;
 integer n,characters=0;reg echoed=0;
 always @(posedge clk) begin
 if(terminal_rx_read) terminal_rx_valid<=0;
 if(terminal_tx_write) begin
 characters<=characters+1;
 if(characters>=105 && terminal_tx_data==65) echoed<=1;
 end
 end
 initial begin
 if (!$value$plusargs("ROM=%s",rom_file)) $fatal(1,"ROM argument required");
 $readmemh(rom_file,program_bytes);
 for(n=0;n<166;n=n+1) begin
 @(negedge clk);loader_write=1;loader_address=n;loader_data=program_bytes[n];
 end
 @(negedge clk);loader_write=0;
 repeat(500) @(negedge clk);reset=0;
 wait(characters==105);
 if(terminal.cells[0]!==73 || terminal.cells[1]!==77 || terminal.cells[2]!==83) $fatal(1,"greeting missing");
 @(negedge clk);terminal_rx_valid=1;
 wait(echoed);repeat(1000) @(negedge clk);
 if(lamps!==65 || terminal_rx_valid) $fatal(1,"keyboard/LED echo");
 $display("PASS: demo greeting, CPU stack/calls, terminal echo and LED response");
 $finish;
 end
 initial begin #20000000;$fatal(1,"timeout");end
endmodule
