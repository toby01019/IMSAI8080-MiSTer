`timescale 1ns/1ps
module tb_hold;
 wire interrupts_enabled,cpu_wait,cpu_hold;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,loader_write=0,stop_requested=0,panel_deposit=0;
 reg [15:0] loader_address=0,panel_address=16'h8000;
 reg [7:0] loader_data=0,switches=0,panel_data=0,terminal_rx_data=0;
 reg terminal_rx_valid=0,terminal_tx_ready=1;
 wire [15:0] address;wire [7:0] lamps,bus_data,status,panel_read_data,terminal_tx_data;
 wire halted,stopped,terminal_rx_read,terminal_tx_write;
 reg watch_lamps=0;
 imsai_machine dut(.*);
 always @(negedge clk) if(watch_lamps && lamps!==8'ha5)
   $fatal(1,"HOLD corrupted an in-flight CPU memory read");
 task put(input [15:0] a,input [7:0] d);
 begin @(negedge clk);loader_address=a;loader_data=d;loader_write=1;
 @(negedge clk);loader_write=0;end
 endtask
 integer n,timeout_count;
 initial begin
 // LDA 9000; OUT FF; JMP 0000.
 put(0,8'h3a);put(1,0);put(2,8'h90);put(3,8'hd3);put(4,8'hff);
 put(5,8'hc3);put(6,0);put(7,0);
 put(16'h9000,8'h5a);put(16'h8000,8'haa);
 repeat(500) @(negedge clk);reset=0;
 wait(lamps===8'ha5);watch_lamps=1;
 for(n=0;n<48;n=n+1) begin
 repeat(n*7+1) @(negedge clk);
 stop_requested=1;timeout_count=0;
 while(!stopped && timeout_count<10000) begin
 @(negedge clk);timeout_count=timeout_count+1;end
 if(!stopped) $fatal(1,"HOLD timeout");
 repeat(10) @(negedge clk);
 if(panel_read_data!==8'haa || !dut.cpu_paused || dut.f1 || dut.f2)
 $fatal(1,"bus not safely released");
 stop_requested=0;repeat(2000) @(negedge clk);
 end
 $display("PASS: 48 STOP/RUN timings preserve in-flight CPU reads and paused state");
 $finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule
