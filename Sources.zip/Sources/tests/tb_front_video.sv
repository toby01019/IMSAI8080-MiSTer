`timescale 1ns/1ps
module tb_front_video;
 reg clk=0;always #10 clk=~clk;
 reg [9:0] x=0,y=0;
 reg [15:0] address_bits=16'ha55a,switch_bits=16'h8042;
 reg [7:0] data_bits=8'ha5,lamps=8'h81,status_bits=8'ha3,input_bits=8'h42;
 reg inte=1,running=1,cpu_wait=0,cpu_hold=0,stopped=0,loaded=1;
 reg [1:0] edit_mode=0;reg deposit_active=0,reset_active=0;
 wire [23:0] rgb;
 imsai_front_video dut(.*);
 task sample(input integer px,py,input [23:0] expected);
 begin
  @(negedge clk);x=px;y=py;repeat(3)@(posedge clk);#1;
  if(rgb!==expected)$fatal(1,"pixel %0d,%0d got %h expected %h",px,py,rgb,expected);
 end
 endtask
 integer fd,xx,yy,i;reg [23:0] frame[0:307199];
 initial begin
  repeat(4)@(posedge clk);
  // First and last bits in both banks, plus real status outputs.
  sample(52,132,24'hfff0e0);sample(76,132,24'h5a1520);sample(216,132,24'hfff0e0);
  lamps=8'h00;sample(52,132,24'h5a1520);lamps=8'h81;
  sample(266,175,24'hfff0e0);sample(289,175,24'h5a1520);
  sample(479,213,24'hfff0e0);inte=0;sample(479,213,24'h5a1520);inte=1;
  sample(556,213,24'h5a1520);cpu_wait=1;sample(556,213,24'hfff0e0);cpu_wait=0;
  sample(650,480,24'h000000);
  $display("LIVE_MAPPING_CHECKS_PASSED; starting frame capture");
  // Full raster captured from the actual synthesizable renderer, not a mock image.
  for(yy=0;yy<480;yy=yy+1)begin
   if(yy%64==0)$display("render row %0d",yy);
   for(xx=0;xx<640;xx=xx+1)begin
   @(negedge clk);x=xx;y=yy;
   @(posedge clk);#1;
   if(dut.x_d<640 && dut.y_d<480)frame[dut.y_d*640+dut.x_d]=rgb;
  end
  end
  repeat(3)begin @(posedge clk);#1;if(dut.x_d<640 && dut.y_d<480)frame[dut.y_d*640+dut.x_d]=rgb;end
  fd=$fopen("../../build/frontpanel-render.ppm","wb");
  $fwrite(fd,"P6\n640 480\n255\n");
  for(i=0;i<307200;i=i+1)$fwrite(fd,"%c%c%c",frame[i][23:16],frame[i][15:8],frame[i][7:0]);
  $fclose(fd);
  $display("PASS: live lamp/data/CPU-status mapping, two-clock raster and full frame capture");$finish;
 end
endmodule
