`timescale 1ns/1ps
module tb_panel;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,stopped=0;reg [10:0] key=0;
 wire stop_requested,panel_deposit;wire [15:0] panel_address;
 wire [7:0] panel_data;wire [1:0] edit_mode;reg wrote=0;
 imsai_panel dut(.*);
 always @(posedge clk) if(panel_deposit) wrote<=1;
 task press(input [7:0] scan);
 begin @(negedge clk);key={~key[10],1'b1,1'b0,scan};
 repeat(3) @(negedge clk);
 key={~key[10],1'b0,1'b0,scan};repeat(3) @(negedge clk);end
 endtask
 initial begin
 repeat(3) @(negedge clk);reset=0;
 press(8'h06);press(8'h0c);
 if(edit_mode || wrote) $fatal(1,"controls accepted while running");
 press(8'h05);if(!stop_requested) $fatal(1,"STOP");stopped=1;
 press(8'h06);press(8'h3e);press(8'h45);press(8'h45);press(8'h45);
 if(panel_address!==16'h8000 || edit_mode!==1) $fatal(1,"hex address");
 press(8'h04);press(8'h1c);press(8'h2e);
 if(panel_data!==8'ha5 || edit_mode!==2) $fatal(1,"hex data");
 press(8'h0c);if(!wrote || edit_mode) $fatal(1,"DEPOSIT");
 press(8'h03);if(panel_address!==16'h8001) $fatal(1,"next");
 press(8'h0b);if(panel_address!==16'h8000) $fatal(1,"previous");
 press(8'h05);if(stop_requested) $fatal(1,"RUN");
 $display("PASS: front-panel keys, hex entry, deposit guard and address stepping");
 $finish;
 end
endmodule
