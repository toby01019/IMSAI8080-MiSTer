`timescale 1ns/1ps
module tb_view_select;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,loaded=0,game_mode=0,frame_end=0;reg [10:0] key=0;wire front_view;
 imsai_view_select dut(.*);
 task frame;begin @(negedge clk);frame_end=1;@(negedge clk);frame_end=0;end endtask
 task event_key(input bit down,ext,input [7:0] code);
 begin @(negedge clk);key={~key[10],down,ext,code};repeat(3)@(negedge clk);end endtask
 initial begin
  repeat(3)@(negedge clk);if(front_view)$fatal(1,"combined default");
  loaded=1;reset=0;frame;if(front_view)$fatal(1,"terminal default");
  event_key(1,0,8'h83);if(front_view)$fatal(1,"changed midframe");frame;if(!front_view)$fatal(1,"F7");
  event_key(0,0,8'h83);frame;if(!front_view)$fatal(1,"release toggled");
  event_key(1,1,8'h83);frame;if(!front_view)$fatal(1,"extended key toggled");
  event_key(1,0,8'h0b);frame;if(!front_view)$fatal(1,"F6 toggled");
  event_key(1,0,8'h83);frame;if(front_view)$fatal(1,"second F7");
  reset=1;repeat(2)@(negedge clk);reset=0;game_mode=1;frame;if(front_view)$fatal(1,"game combined default");
  event_key(1,0,8'h83);frame;if(!front_view)$fatal(1,"game zoom");
  event_key(1,0,8'h83);frame;if(front_view)$fatal(1,"game combined return");
  loaded=0;game_mode=0;event_key(1,0,8'h83);frame;if(!front_view)$fatal(1,"zoom without ROM");
  event_key(1,0,8'h83);frame;if(front_view)$fatal(1,"return without ROM");
  $display("PASS: combined default, frame-boundary F7 zoom/return, release and extended filtering");$finish;
 end
endmodule
