`timescale 1ns/1ps
module tb_combined_video;
 reg clk_system=0;always #10 clk_system=~clk_system;
 reg machine_reset=1,tx_write=0;reg [7:0]tx_data=0;reg [10:0]keyboard_event=0;
 wire tx_ready;wire [23:0]pixel_rgb;wire VGA_HS,VGA_VS,VGA_DE,CLK_VIDEO,CE_PIXEL;
 imsai_video_harness dut(.*);
 reg [9:0]xq=0,yq=0,xd=0,yd=0;
 always @(posedge clk_system)begin xq<=dut.x;yq<=dut.y;xd<=xq;yd<=yq;end
 reg [23:0]frame[0:307199];integer fd,i;
 reg capture=0;
 always @(posedge clk_system)begin
  #1;
  if(capture && xd<640 && yd<480)frame[yd*640+xd]=pixel_rgb;
  if(dut.pixel_enable && dut.x==80 && dut.y>=250 && dut.y<448 && dut.scaled_x!=0)$fatal(1,"scale left");
  if(dut.pixel_enable && dut.x==559 && dut.y>=250 && dut.y<448 && dut.scaled_x!=638)$fatal(1,"scale right %0d",dut.scaled_x);
  if(dut.x==64 && dut.y==464 && dut.label_char!="F")$fatal(1,"F1 help truncated");
  if(dut.x==72 && dut.y==464 && dut.label_char!="1")$fatal(1,"F1 digit truncated");
  if(dut.x==64 && dut.y==232 && dut.label_char!="S")$fatal(1,"STEP note truncated");
 end
 task put(input [7:0]v);
 begin wait(tx_ready);@(negedge clk_system);tx_write=1;tx_data=v;@(negedge clk_system);tx_write=0;end
 endtask
 task dump(input integer zoom);
 begin
  fd=$fopen(zoom?"../../build/zoom-render.ppm":"../../build/combined-render.ppm","wb");
  $fwrite(fd,"P6\n640 480\n255\n");
  for(i=0;i<307200;i=i+1)$fwrite(fd,"%c%c%c",frame[i][23:16],frame[i][15:8],frame[i][7:0]);
  $fclose(fd);
 end
 endtask
 task next_frame;
 begin wait(dut.x==0 && dut.y==480);wait(dut.x==0 && dut.y==0);end
 endtask
 reg [8*80-1:0]line1="IMSAI 8080 TERMINAL READY";
 initial begin
  repeat(20)@(negedge clk_system);machine_reset=0;
  wait(tx_ready);
  put("I");put("M");put("S");put("A");put("I");put(" ");put("8");put("0");put("8");put("0");put(13);put(10);
  put("B");put("A");put("S");put("I");put("C");put(" ");put("R");put("E");put("A");put("D");put("Y");put(13);put(10);put(">");
  // Begin at first frame after the terminal is filled; inputs are the integrated video source verbatim.
  capture=1;wait(dut.x==0 && dut.y==480);capture=0;dump(0);
  if(dut.front_view)$fatal(1,"combined default");
  if($test$plusargs("COMBINED_ONLY"))begin $display("PASS: latest combined raster, intact help labels and scale boundaries");$finish;end
  $display("COMBINED_FRAME_CAPTURED; checking F7 zoom");
  @(negedge clk_system);keyboard_event={1'b1,1'b1,1'b0,8'h83};
  repeat(4)@(negedge clk_system);keyboard_event={1'b0,1'b0,1'b0,8'h83};
  wait(dut.front_view);capture=1;next_frame;wait(dut.x==0 && dut.y==480);capture=0;dump(1);
  $display("PASS: integrated combined/zoom frames and 4:3 nearest-neighbor scale boundaries");$finish;
 end
endmodule
