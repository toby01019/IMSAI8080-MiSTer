`timescale 1ns/1ps
module tb_original_game;
 wire interrupts_enabled,cpu_wait,cpu_hold;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,loader_write=0,stop_requested=0,panel_deposit=0;
 reg [15:0] loader_address=0,panel_address=0;
 reg [7:0] loader_data=0,switches=255,panel_data=0,terminal_rx_data=0;
 reg terminal_rx_valid=0,terminal_tx_ready=1;
 wire [15:0] address;wire [7:0] lamps,bus_data,status,panel_read_data,terminal_tx_data;
 wire halted,stopped,terminal_rx_read,terminal_tx_write;
 reg [7:0] rom[0:43];reg [4095:0] rom_file;integer n;
 imsai_machine #(.CLOCKS_PER_CPU(4)) dut(.*);
 initial begin
 if(!$value$plusargs("GAME=%s",rom_file)) $fatal(1,"GAME path required");
 $readmemh(rom_file,rom);
 for(n=0;n<44;n=n+1) begin
 @(negedge clk);loader_write=1;loader_address=n;loader_data=rom[n];end
 @(negedge clk);loader_write=0;repeat(100) @(negedge clk);
 // Defined test-only power-up registers: original program does not initialize B/C/E.
 dut.cpu.r16_bc=16'hfe00;dut.cpu.r16_de=16'h00ff;
 reset=0;
 wait(lamps===8'h02); // Original RLC moves a single illuminated bit left.
 if(dut.cpu.r16_sp!==16'h00ff) $fatal(1,"original speed input");
 @(negedge clk);switches=8'hfd; // Toggle the switch under the illuminated bit.
 wait(lamps===0);
 repeat(100000) @(negedge clk);
 if(lamps!==0) $fatal(1,"killed bit returned");
 for(n=0;n<44;n=n+1) if(dut.ram[n]!==rom[n]) $fatal(1,"original bytes changed");
 $display("PASS: unmodified 44-byte original game, rotation, switch hit and debounce");
 $finish;
 end
 initial begin #20000000;$fatal(1,"original game timeout");end
endmodule
