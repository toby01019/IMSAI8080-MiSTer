`timescale 1ns/1ps
module tb_terminal;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,tx_write=0;reg [7:0] tx_data=0;
 reg [9:0] x=64,y=64;wire ready,text_pixel;
 imsai_terminal dut(.*);
 task send(input [7:0] b);
 begin @(negedge clk);while(!ready) @(negedge clk);
 tx_data=b;tx_write=1;@(negedge clk);tx_write=0;end
 endtask
 integer n;
 initial begin
 repeat(4) @(negedge clk);reset=0;
 while(!ready) @(negedge clk);
 send(65);send(66);send(8);send(67);
 if(dut.cells[0]!==65 || dut.cells[1]!==67 || dut.col!==2) $fatal(1,"write/backspace");
 x=66;y=66;repeat(3) @(negedge clk);
 if(!text_pixel) $fatal(1,"glyph raster position");
 x=65;repeat(3) @(negedge clk);
 if(text_pixel) $fatal(1,"glyph background");
 send(13);send(10);
 for(n=1;n<17;n=n+1) begin send(48+n);send(13);send(10);end
 while(!ready) @(negedge clk);
 if(dut.top!==2 || dut.line!==15 || dut.cells[128]!==32) $fatal(1,"scroll/clear");
 x=66;y=66;repeat(3) @(negedge clk);
 if(dut.character!==50 || !text_pixel) $fatal(1,"scrolled raster address");
 // Star Trek needs its map symbols and one complete 80-column row.
 reset=1;repeat(4)@(negedge clk);reset=0;
 while(!ready)@(negedge clk);
 send(60);x=69;y=66;repeat(3)@(negedge clk);
 if(!text_pixel)$fatal(1,"missing less-than glyph");
 send(42);x=73;y=67;repeat(3)@(negedge clk);
 if(!text_pixel)$fatal(1,"missing star glyph");
 send(33);x=79;y=66;repeat(3)@(negedge clk);
 if(!text_pixel)$fatal(1,"missing base glyph");
 for(n=3;n<80;n=n+1)send(65);
 if(dut.col!==0 || dut.line!==1 || dut.cells[79]!==65)$fatal(1,"80-column wrap");
 send(66);
 if(dut.cells[128]!==66 || dut.col!==1)$fatal(1,"next row write");
 $display("PASS: 80-column terminal, map symbols, backspace, CR/LF, scrolling and glyph raster");
 $finish;
 end
 initial begin #1000000;$fatal(1,"timeout");end
endmodule
