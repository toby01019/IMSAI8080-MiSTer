`timescale 1ns/1ps
module tb_machine;
 wire interrupts_enabled,cpu_wait,cpu_hold;
    reg clk = 0;
    always #10 clk = ~clk;
    reg reset = 1;
    reg [7:0] switches = 0;
    reg loader_write = 0;
    reg [15:0] loader_address = 0;
    reg [7:0] loader_data = 0;
    wire [7:0] lamps, bus_data, status;
    wire [15:0] address;
    wire halted;
    reg stop_requested=0,panel_deposit=0;
    reg [15:0] panel_address=0;
    reg [7:0] panel_data=0;
    wire stopped;wire [7:0] panel_read_data;
    reg [7:0] terminal_rx_data = 8'h51;
    reg terminal_rx_valid = 1;
    reg terminal_tx_ready = 1;
    wire terminal_rx_read, terminal_tx_write;
    wire [7:0] terminal_tx_data;
    reg saw_tx = 0, saw_rx = 0;
    always @(posedge clk) begin
        if (terminal_rx_read) saw_rx <= 1;
        if (terminal_tx_write) begin
            if (terminal_tx_data !== 8'h51) $fatal(1,"terminal output mismatch");
            saw_tx <= 1;
        end
    end
    imsai_machine dut(.*);
    task put(input [15:0] a, input [7:0] d);
        begin
            @(negedge clk);
            loader_address = a; loader_data = d; loader_write = 1;
            @(negedge clk); loader_write = 0;
        end
    endtask
    task run_cpu;
        begin repeat (500) @(negedge clk); reset = 0; end
    endtask
    task wait_lamps(input [7:0] expected);
        integer n;
        begin
            n = 0;
            while (lamps !== expected && n < 100000) begin
                @(negedge clk); n = n + 1;
            end
            if (lamps !== expected)
                $fatal(1,"lamps expected %h got %h at %h status %h", expected, lamps, address, status);
        end
    endtask
    integer n;reg [7:0] saved;
    initial begin
        // Manual test: IN FF; OUT FF; JMP 0000.
        put(0,8'hdb); put(1,8'hff); put(2,8'hd3); put(3,8'hff);
        put(4,8'hc3); put(5,0); put(6,0);
        switches = 8'h5a; run_cpu(); wait_lamps(8'ha5);
        switches = 8'hc3; wait_lamps(8'h3c);
        $display("PASS: IN/OUT FF and inverted lamp polarity");
        reset = 1; repeat (500) @(negedge clk);
        // Complement version: IN FF; CMA; OUT FF; JMP 0000.
        put(2,8'h2f); put(3,8'hd3); put(4,8'hff);
        put(5,8'hc3); put(6,0); put(7,0);
        switches = 8'h96; run_cpu(); wait_lamps(8'h96);
        $display("PASS: manual complement test");
        reset = 1; repeat (500) @(negedge clk);
        // MVI A,42; STA 8000; XRA A; LDA 8000; OUT FF; HLT.
        put(0,8'h3e); put(1,8'h42); put(2,8'h32); put(3,0); put(4,8'h80);
        put(5,8'haf); put(6,8'h3a); put(7,0); put(8,8'h80);
        put(9,8'hd3); put(10,8'hff); put(11,8'h76);
        run_cpu(); wait_lamps(8'hbd);
        repeat (10000) @(negedge clk);
        if (!halted || dut.ram[16'h8000] !== 8'h42)
            $fatal(1,"high RAM or HLT failed");
        $display("PASS: RAM above 32 KiB, load/store, HLT");
        reset = 1; repeat (500) @(negedge clk);
        // Poll status, read a byte and send it to terminal and lamp ports.
        put(0,8'hdb); put(1,8'h11); put(2,8'he6); put(3,1);
        put(4,8'hca); put(5,0); put(6,0);
        put(7,8'hdb); put(8,8'h10); put(9,8'hd3); put(10,8'h10);
        put(11,8'hd3); put(12,8'hff); put(13,8'h76);
        run_cpu(); wait_lamps(8'hae); repeat (10000) @(negedge clk);
        if (!saw_rx || !saw_tx || !halted) $fatal(1,"terminal IO failed");
        $display("PASS: terminal status, input and output executed by CPU");
        reset=1;repeat(500) @(negedge clk);
        // LXI H,8000; MVI M,00; INR M; JMP 0005.
        put(0,8'h21);put(1,0);put(2,8'h80);put(3,8'h36);put(4,0);
        put(5,8'h34);put(6,8'hc3);put(7,5);put(8,0);
        run_cpu();repeat(10000) @(negedge clk);
        stop_requested=1;
        n=0;
        while(!stopped && n<10000) begin @(negedge clk);n=n+1;end
        if(!stopped) $fatal(1,"STOP not acknowledged");
        panel_address=16'h8000;repeat(10) @(negedge clk);
        saved=panel_read_data;
        repeat(5000) @(negedge clk);
        if(panel_read_data!==saved || dut.ram[16'h8000]!==saved) $fatal(1,"CPU wrote while stopped");
        panel_data=8'ha5;panel_deposit=1;@(negedge clk);panel_deposit=0;
        repeat(10) @(negedge clk);
        if(panel_read_data!==8'ha5) $fatal(1,"deposit/readback");
        panel_address=16'h9000;panel_data=8'h42;panel_deposit=1;
        @(negedge clk);panel_deposit=0;repeat(10) @(negedge clk);
        if(panel_read_data!==8'h42) $fatal(1,"examine selected address");
        stop_requested=0;repeat(10000) @(negedge clk);
        if(stopped || dut.ram[16'h8000]===8'ha5) $fatal(1,"RUN did not resume");
        panel_address=16'h9000;panel_data=8'h99;panel_deposit=1;
        @(negedge clk);panel_deposit=0;repeat(10) @(negedge clk);
        if(dut.ram[16'h9000]!==8'h42) $fatal(1,"deposit accepted during RUN");
        $display("PASS: safe STOP, stable memory, EXAMINE/DEPOSIT and RUN resume");
        $finish;
    end
    initial begin #20000000; $fatal(1,"global timeout"); end
endmodule
