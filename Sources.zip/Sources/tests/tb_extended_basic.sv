`timescale 1ns/1ps
module tb_extended_basic;
 wire interrupts_enabled,cpu_wait,cpu_hold;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,loader_write=0;reg [15:0] loader_address=0;reg [7:0] loader_data=0,switches=0;
 wire [7:0] lamps,bus_data,status;wire [15:0] address;wire halted;
 reg stop_requested=0,panel_deposit=0;reg [15:0] panel_address=0;reg [7:0] panel_data=0;
 wire stopped;wire [7:0] panel_read_data;
 reg [7:0] terminal_rx_data=0;reg terminal_rx_valid=0;
 wire terminal_rx_read,terminal_tx_write;wire [7:0] terminal_tx_data;
 wire terminal_tx_ready;reg [9:0] x=64,y=64;wire text_pixel;
 imsai_machine #(.CLOCKS_PER_CPU(4)) machine(.*);
 imsai_terminal terminal(.clk(clk),.reset(reset),.tx_write(terminal_tx_write),
 .tx_data(terminal_tx_data),.x(x),.y(y),.ready(terminal_tx_ready),.text_pixel(text_pixel));
 reg [7:0] program_bytes[0:65535];reg [4095:0] rom_file;
 reg [8191:0] output_text=0;integer n,game=0;
 always @(posedge clk) if(terminal_tx_write) begin
 output_text={output_text,terminal_tx_data};$write("%c",terminal_tx_data);$fflush();end
 task send_line(input [1023:0] line_text);
 integer k;
 begin line_text={line_text[1015:0],8'd13};
 for(k=127;k>=0;k=k-1)if(line_text[k*8+:8]!=0)begin
 @(negedge clk);terminal_rx_data=line_text[k*8+:8];terminal_rx_valid=1;
 wait(terminal_rx_read);@(negedge clk);terminal_rx_valid=0;
 repeat(500)@(negedge clk);end end endtask
 function automatic integer contains(input [8191:0] hay,input [255:0] needle);
 integer j,k,len;reg same;
 begin len=0;for(k=0;k<32;k=k+1)if(needle[k*8+:8]!=0)len=k+1;
 contains=0;for(j=0;j<1024-len+1;j=j+1)begin
 same=1;for(k=0;k<len;k=k+1)if(hay[(j+k)*8+:8]!=needle[k*8+:8])same=0;
 if(same)contains=1;end end endfunction
 initial begin
 if(!$value$plusargs("IMAGE=%s",rom_file))$fatal(1,"IMAGE required");
 if($value$plusargs("GAME=%d",game))begin end
 $readmemh(rom_file,program_bytes,0,61951);
 for(n=0;n<61952;n=n+1)begin
 @(negedge clk);loader_write=1;loader_address=n;loader_data=program_bytes[n];end
 @(negedge clk);loader_write=0;repeat(500)@(negedge clk);reset=0;
 if(game==0)begin
 while(!contains(output_text,"OK"))repeat(10000)@(negedge clk);
 repeat(10000)@(negedge clk);output_text=0;
 send_line("PRINT SQR(9)");repeat(3000000)@(negedge clk);
 if(!contains(output_text," 3"))$fatal(1,"Floating point SQR failed PC %h input %h, rx %b",address,machine.ram['h35a],terminal_rx_valid);
 output_text=0;send_line("A$=\"STAR TREK\"");repeat(200000)@(negedge clk);
 send_line("PRINT MID$(A$,6,4)");repeat(3000000)@(negedge clk);
 if(!contains(output_text,"TREK"))$fatal(1,"String or MID$ failed");
 $display("\nPASS: 8K BASIC 4.0 boots, floating point SQR, strings and MID$");
 end else begin
 while(!contains(output_text,"COMMAND"))repeat(10000)@(negedge clk);
 output_text=0;send_line("SRS");repeat(1000000)@(negedge clk);
 if(!contains(output_text,"STARDATE"))$fatal(1,"Star Trek short range scan failed");
 $display("\nPASS: historical Star Trek listing loads, runs and accepts SRS");
 end
 $finish;end
 initial begin #6000000000;$fatal(1,"Extended BASIC timeout PC %h, script %h%h",address,machine.ram['hf0f1],machine.ram['hf0f0]);end
endmodule

