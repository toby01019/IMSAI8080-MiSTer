`timescale 1ns/1ps
module tb_keyboard;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,read_byte=0;reg enabled=1;reg [10:0] key=0;
 wire [7:0] data;wire valid;
 imsai_keyboard dut(.*);
 task event_key(input press,input [7:0] scan);
 begin @(negedge clk);key={~key[10],press,1'b0,scan};repeat(3) @(negedge clk);end
 endtask
 task pop;
 begin @(negedge clk);read_byte=1;@(negedge clk);read_byte=0;end
 endtask
 integer n;
 initial begin
 repeat(3) @(negedge clk);reset=0;
 event_key(1,8'h1c);event_key(0,8'h1c);event_key(1,8'h32);
 if(!valid || data!==65 || dut.count!==2) $fatal(1,"press/release");
 pop();if(data!==66) $fatal(1,"FIFO order");pop();
 if(valid) $fatal(1,"empty");
 for(n=0;n<17;n=n+1) event_key(1,8'h1c);
 if(dut.count!==16) $fatal(1,"overflow");
 for(n=0;n<16;n=n+1) pop();
 if(valid) $fatal(1,"drain");
 enabled=0;event_key(1,8'h1c);
 if(valid) $fatal(1,"panel input leaked into terminal");
 enabled=1;repeat(3) @(negedge clk);
 if(valid) $fatal(1,"old panel key replayed");
 event_key(1,8'h32);if(!valid || data!==66) $fatal(1,"terminal did not re-enable");
 $display("PASS: keyboard ASCII, queue order, overflow and panel input isolation");
 $finish;
 end
endmodule
