`timescale 1ns/1ps
module tb_basic;
 wire interrupts_enabled,cpu_wait,cpu_hold;
 reg clk=0;always #10 clk=~clk;
 reg reset=1,loader_write=0;reg [15:0] loader_address=0;reg [7:0] loader_data=0,switches=0;
 wire [7:0] lamps,bus_data,status;wire [15:0] address;wire halted;
 reg stop_requested=0,panel_deposit=0;reg [15:0] panel_address=0;reg [7:0] panel_data=0;
 wire stopped;wire [7:0] panel_read_data;
 reg [7:0] terminal_rx_data=0;reg terminal_rx_valid=0;
 wire terminal_rx_read,terminal_tx_write;wire [7:0] terminal_tx_data;
 wire terminal_tx_ready;reg [9:0] x=64,y=64;wire text_pixel;
 imsai_machine #(.CLOCKS_PER_CPU(4)) machine(.*);
 imsai_terminal terminal(.clk(clk),.reset(reset),.tx_write(terminal_tx_write),
 .tx_data(terminal_tx_data),.x(x),.y(y),.ready(terminal_tx_ready),.text_pixel(text_pixel));
 reg [7:0] program_bytes[0:63482];reg [4095:0] rom_file;
 reg [8191:0] output_text=0;integer n;
 always @(posedge clk) if(terminal_tx_write) begin
   output_text={output_text,terminal_tx_data};$write("%c",terminal_tx_data);
 end
 task send_line(input [1023:0] line_text);
 integer k;
 begin
 line_text={line_text[1015:0],8'd13};
 for(k=127;k>=0;k=k-1) if(line_text[k*8+:8]!=0)begin
 @(negedge clk);terminal_rx_data=line_text[k*8+:8];terminal_rx_valid=1;
 wait(terminal_rx_read);@(negedge clk);terminal_rx_valid=0;
 repeat(500) @(negedge clk);
 end
 end
 endtask
 function automatic integer contains(input [8191:0] hay,input [127:0] needle);
 integer j,k,len;reg same;
 begin
 len=0;for(k=0;k<16;k=k+1)if(needle[k*8+:8]!=0)len=k+1;
 contains=0;for(j=0;j<1024-len+1;j=j+1)begin
 same=1;for(k=0;k<len;k=k+1)if(hay[(j+k)*8+:8]!=needle[k*8+:8])same=0;
 if(same)contains=1;end
 end
 endfunction
 initial begin
 if(!$value$plusargs("BASIC=%s",rom_file))$fatal(1,"BASIC path required");
 $readmemh(rom_file,program_bytes);
 for(n=0;n<63483;n=n+1) begin
 @(negedge clk);loader_write=1;loader_address=n;loader_data=program_bytes[n];end
 @(negedge clk);loader_write=0;repeat(500)@(negedge clk);reset=0;
 while(!contains(output_text,">"))repeat(1000)@(negedge clk);
 send_line("PRINT 6*7");repeat(150000)@(negedge clk);
 if(!contains(output_text,"42"))$fatal(1,"BASIC arithmetic missing");
 send_line("10 FOR A=1 TO 3");repeat(100000)@(negedge clk);
 send_line("20 PRINT A");repeat(100000)@(negedge clk);
 send_line("30 NEXT A");repeat(100000)@(negedge clk);
 send_line("40 STOP");repeat(100000)@(negedge clk);
 output_text=0;send_line("RUN");repeat(250000)@(negedge clk);
 if(!contains(output_text,{8'd49,8'd13,8'd10})||!contains(output_text,{8'd50,8'd13,8'd10})||!contains(output_text,{8'd51,8'd13,8'd10}))
 $fatal(1,"Stored BASIC FOR/NEXT program failed");
 if(contains(output_text,"WHAT?")||contains(output_text,"HOW?")||contains(output_text,"SORRY"))
 $fatal(1,"Unexpected BASIC error");
 output_text=0;send_line("INPUT B");repeat(100000)@(negedge clk);
 send_line("8");repeat(100000)@(negedge clk);
 output_text=0;send_line("PRINT B/2");repeat(150000)@(negedge clk);
 if(!contains(output_text,{8'd52,8'd13,8'd10}))$fatal(1,"BASIC INPUT or division failed");
 $display("\nPASS: historical BASIC boot, arithmetic, stored FOR/NEXT, INPUT and division");$finish;
 end
 initial begin #200000000;$fatal(1,"BASIC timeout at %h",address);end
endmodule
