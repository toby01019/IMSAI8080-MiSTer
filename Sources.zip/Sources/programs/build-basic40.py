from pathlib import Path
# Historical Microsoft/MITS interpreter: no open redistribution license established.
# This adapter is for the user's separate local installation.
root=Path(__file__).resolve().parents[1]
work=root.parent/'05_Historische_Programme/BASIC_4_0_privater_Runtime'
tape=(work/'basic8k40.tap').read_bytes()
import hashlib
assert hashlib.sha256(tape).hexdigest()=='e610937291d20860ff12068e5bb41edecdd7473097e1344cf504046e120cbb6a'
original=bytearray(8192);cursor=450;records=0
while cursor<len(tape):
 marker=tape[cursor];cursor+=1
 if marker==0x3c:
  count=tape[cursor] or 256;lo,hi=tape[cursor+1:cursor+3];cursor+=3
  data=tape[cursor:cursor+count];cursor+=count
  assert (lo+hi+sum(data))%256==tape[cursor];cursor+=1
  address=lo+hi*256;assert address+count<=len(original)
  original[address:address+count]=data;records+=1
 elif marker==0x78:
  assert tape[cursor:cursor+2]==b'\x00\x00';break
 else:assert marker==0
assert records==28
assert original[0x1a12:0x1a15]==bytes.fromhex('CD 3A 19')
assert original[0x54f:0x552]==bytes.fromhex('D3 01 F5')
assert original[0x556:0x559]==bytes.fromhex('DB 00 E6')

for game in (False,True):
 image=bytearray(65536);image[:len(original)]=original
 image[0x1a12:0x1a15]=bytes.fromhex('C3 00 F0')
 code=bytearray()
 for a,v in [(0x548,0x11),(0x54a,2),(0x54b,0xca),(0x54f,0xc3),(0x550,0x60),(0x551,0xf1),(0x556,0xc3),(0x557,0),(0x558,0xf1),(0x60d,0x11),(0x60f,1),(0x610,0xc4),(0x669,0x11),(0x66b,1),(0x66c,0xc8)]:code.extend([0x3e,v,0x32,a&255,a>>8])
 code.extend(bytes.fromhex('C3 15 1A'));image[0xf000:0xf000+len(code)]=code
 stub=bytes.fromhex('E5 2A F0 F0 7E B7 CA 11 F1 23 22 F0 F0 E1 C9 00 00 E1 DB 11 E6 01 CA 12 F1 DB 10 E6 7F C9');image[0xf100:0xf100+len(stub)]=stub
 image[0xf160:0xf167]=bytes.fromhex('F5 E6 7F D3 10 F1 C9');image[0xf0f0:0xf0f2]=bytes.fromhex('00 80')
 lines=['32768','80','Y']
 if game:
  for line in (root/'programs/superstartrek.bas').read_text().splitlines():
   quoted=False;compact='';i=0
   while i<len(line):
    c=line[i]
    if not quoted and line[i:i+3]=='REM':compact+='REM';break
    if not quoted and line[i:i+5]=='PRINT':compact+='?';i+=5;continue
    if c=='"':quoted=not quoted
    if c!=' ' or quoted:compact+=c
    i+=1
   assert len(compact)<=72,(len(compact),compact)
   lines.append(compact)
  lines+=['CLEAR 600','RUN']
 script=('\r'.join(lines)+'\r').encode()+b'\0';image[0x8000:0x8000+len(script)]=script
 name='superstartrek-basic40' if game else 'basic8k40-mister'
 (root/'programs'/f'{name}.bin').write_bytes(image[:0xf200]);(root/'tests'/f'{name}.hex').write_text('\n'.join(f'{v:02x}' for v in image[:0xf200]))
 print(name,len(script))
