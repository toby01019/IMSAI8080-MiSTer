"""Reconstruct the archived 1977 listing and audit its address operands.

Input is kept untouched; all corrections and the local terminal adapter are
reported separately. This is an adapted historical interpreter, not a claim
that the faulty transcription is a byte-exact original executable.
"""
from pathlib import Path
import re, json

root = Path(__file__).resolve().parent
source = root / 'tinybasic-v3-archive.asm'
rows=[]
symbols={'BOTSCR':0x80,'TOPSCR':0x200,'BOTRAM':0x2000,'DFTLMT':0x4000,'BOTROM':0xf000,
         '@CR':13,'@LF':10,'BUFFER':0xca,'BUFEND':0x14e,'STACK':0x200,
         'TXTUNF':0x2000,'TEXT':0x2002,'STKLMT':0x152,'VARNXT':0xbb,'PRTNUM':0xf6ae,'RANEND':0xf793}
ops=set('IN OUT PCHL LXI CALL MVI JMP CMP JZ MOV SHLD STA DB LHLD PUSH POP ORA DCX STAX RST DAD INX JNZ ADD ADC JNC XCHG JC RET CNZ RZ RNZ RC RNC SUB SUI CPI ANI XRA ANA CMA CMC STC RLC RRC RAL RAR SPHL XTHL LDAX LDA INR DCR ADI ACI SBB SBI ORI XRI HLT NOP DI EI DS EQU ITEM JP JM JPE JPO CP CM CZ CNC CC CPE CPO DAA'.split())
for line in source.read_text().splitlines():
    line=line.replace('FODB ','F0DB ').replace('FOE7 ','F0E7 ')
    m=re.match(r'^([0-9A-F]{4})\s+([0-9A-F]+)?\s+(\d+)\s*(.*)',line)
    if not m: continue
    addr=int(m[1],16); raw=bytes.fromhex(m[2]) if m[2] else b''
    # Four printed addresses in the EX5 sequence are shifted; the next label
    # NEW at F0FF establishes the correct contiguous instruction layout.
    addr={1798:0xf0f8,1800:0xf0f9,1802:0xf0fa,1804:0xf0fc,4027:0xf7ee}.get(int(m[3]),addr)
    words=m[4].split(None,2)
    if not words:
        rows.append((addr,raw,'','',line));continue
    if words[0] not in ops:
        symbols[words[0]]=addr
        words=words[1:]
    if not words:
        rows.append((addr,raw,'','',line));continue
    op=words[0]; arg=words[1].split()[0] if len(words)>1 else ''
    rows.append((addr,raw,op,arg,line))

image=bytearray(65536); occupied={}; corrections=['EX5 listing addresses: F0F9/F0FA/F0FC/F0FD -> F0F8/F0F9/F0FA/F0FC', 'IN listing ANI address F7ED -> F7EE']
def value(expr):
    if expr in symbols:return symbols[expr]
    m=re.fullmatch(r'(.+)([+-])(\d+)',expr)
    if m:return value(m[1])+(int(m[3]) if m[2]=='+' else -int(m[3]))
    if re.fullmatch(r'[0-9A-F]+H',expr):return int(expr[:-1],16)
    if expr.isdigit():return int(expr)
    raise ValueError(expr)

for addr,raw,op,arg,line in rows:
    if not raw:continue
    # A typo in the transcription places the ANI immediately after IN at F7ED.
    if addr==0xf7ed:addr=0xf7ee;corrections.append('F7ED listing address -> F7EE (IN is two bytes)')
    data=bytearray(raw)
    regs={'B':0,'C':1,'D':2,'E':3,'H':4,'L':5,'M':6,'A':7}
    pairs={'B':0,'D':1,'H':2,'SP':3,'PSW':3}
    fixed={'IN':0xdb,'OUT':0xd3,'XTHL':0xe3,'XCHG':0xeb,'PCHL':0xe9,'SPHL':0xf9,
        'RET':0xc9,'RNZ':0xc0,'RZ':0xc8,'RNC':0xd0,'RC':0xd8,'RP':0xf0,'RM':0xf8,
        'JMP':0xc3,'JNZ':0xc2,'JZ':0xca,'JNC':0xd2,'JC':0xda,'JP':0xf2,'JM':0xfa,
        'CALL':0xcd,'CNZ':0xc4,'CZ':0xcc,'CNC':0xd4,'CC':0xdc,'CP':0xf4,'CM':0xfc,
        'SHLD':0x22,'LHLD':0x2a,'STA':0x32,'LDA':0x3a,'CPI':0xfe,'ANI':0xe6,
        'ADI':0xc6,'SUI':0xd6,'XRI':0xee,'ORI':0xf6,'ACI':0xce,'SBI':0xde,
        'CMA':0x2f,'CMC':0x3f,'STC':0x37,'RLC':0x07,'RRC':0x0f,'RAL':0x17,'RAR':0x1f}
    expected=fixed.get(op)
    if op=='MOV' and ',' in arg:
        a,b=arg.split(',');expected=0x40+8*regs[a]+regs[b]
    if op in {'ADD','ADC','SUB','SBB','ANA','XRA','ORA','CMP'} and arg in regs:
        expected={'ADD':0x80,'ADC':0x88,'SUB':0x90,'SBB':0x98,'ANA':0xa0,'XRA':0xa8,'ORA':0xb0,'CMP':0xb8}[op]+regs[arg]
    if op in {'INR','DCR','MVI'} and arg.split(',')[0] in regs:
        expected={'INR':4,'DCR':5,'MVI':6}[op]+8*regs[arg.split(',')[0]]
    if op in {'LXI','INX','DCX','DAD','PUSH','POP'} and arg.split(',')[0] in pairs:
        expected={'LXI':1,'INX':3,'DCX':0x0b,'DAD':9,'PUSH':0xc5,'POP':0xc1}[op]+16*pairs[arg.split(',')[0]]
    # Archive mistakenly names PRTCHS here; the scan and object bytes say PRTLN.
    if addr==0xf54a:arg='PRTLN'
    # Mnemonic transcription errors; these raw opcodes agree with the scan.
    if addr in {0xf28c,0xf53e}:expected=None
    if addr==0xf79b:expected=0x11
    if expected is not None and data[0]!=expected:
        corrections.append(f'{addr:04X}: opcode {data[0]:02X} -> {expected:02X} ({op} {arg})')
        data[0]=expected
    if op in {'MVI','CPI','ANI','ADI','SUI','ACI','SBI','XRI','ORI','IN','OUT'} and len(data)==2:
        operand=arg.split(',',1)[-1]
        quoted=re.search(r"\b(?:MVI\s+[A-Z],|CPI\s+|ADI\s+|SUI\s+)'(.)'",line)
        try:immediate=ord(quoted[1]) if quoted else value(operand)
        except ValueError:immediate=None
        if immediate is not None and 0<=immediate<256 and data[1]!=immediate:
            corrections.append(f'{addr:04X}: immediate {data[1]:02X} -> {immediate:02X} ({op})')
            data[1]=immediate
    expr=arg
    if op=='LXI':expr=arg.split(',',1)[-1]
    if op in {'LXI','CALL','JMP','JZ','JNZ','JC','JNC','JP','JM','JPE','JPO','SHLD','LHLD','STA','LDA','CNZ','CZ','CP','CM'} and len(raw)==3:
        try:v=value(expr)
        except ValueError:v=None
        if v is not None:
            desired=bytes([v&255,v>>8])
            if data[1:]!=desired:
                corrections.append(f'{addr:04X}: {raw.hex().upper()} -> {data[0]:02X}{desired.hex().upper()} ({op} {arg})')
                data[1:]=desired
    # CURRNT is a pointer to a zero word, not the zero value itself. Retain LXI
    # at F056 despite the archive README's incorrect suggested LHLD erratum.
    for i,b in enumerate(data):
        if addr+i in occupied:raise ValueError(f'Overlapping bytes at {addr+i:04X}')
        occupied[addr+i]=b; image[addr+i]=b

for addr,raw,op,arg,line in rows:
    if op!='ITEM':continue
    target=arg.rsplit(',',1)[-1]
    if target not in symbols:continue
    m=re.search(r"ITEM\s+'([^']*)'",line)
    pointer=addr+(len(m[1]) if m else 0)
    dest=symbols[target]
    desired=bytes([dest>>8,dest&255])
    if image[pointer:pointer+2]!=desired:
        corrections.append(f'{pointer:04X}: table target -> {dest:04X} ({target})')
        image[pointer:pointer+2]=desired
# The transcription omitted the closing XTHL of TSTC, between INX H and RET.
image[0xf5cd]=0xe3;occupied[0xf5cd]=0xe3
corrections.append('F5CD: restore omitted XTHL, paired with TSTC entry XTHL')
missing=[a for a in range(0xf000,0xf7fb) if a not in occupied]
if missing:raise ValueError(f'Missing listing bytes: {missing}')
# Local reset jump and terminal adapter. The interpreter remains at F000.
image[:3]=bytes.fromhex('C3 00 F0')
# OUTCH target F7D6: preserve A, wait for TX ready, send; CR also emits LF.
out=bytes.fromhex('F5 DB 11 E6 02 CA D7 F7 F1 D3 10 FE 0D C0 3E 0A CD D6 F7 3E 0D C9')
# CHKIO target F7EC: nonblocking input, mask bit7, Ctrl-C restarts INIT.
inp=bytes.fromhex('DB 11 E6 01 C8 DB 10 E6 7F FE 03 C0 C3 00 F0')
assert len(out)==22 and len(inp)==15
image[0xf7d6:0xf7ec]=out;image[0xf7ec:0xf7fb]=inp
(root/'tinybasic-v3-mister.bin').write_bytes(image[:0xf7fb])
(root.parent/'tests/tinybasic-v3.hex').write_text('\n'.join(f'{b:02x}' for b in image[:0xf7fb])+'\n')
(root/'tinybasic-v3-corrections.json').write_text(json.dumps(corrections,indent=2)+'\n')
print('\n'.join(corrections));print('Built historical Tiny BASIC with local terminal adapter:',len(image[:0xf7fb]),'bytes')
