; IMSAI prototype terminal test (8080), MIT
; Custom terminal ports: 10h data, 11h status (bit0 RX, bit1 TX ready).
        LXI SP,0FFF0H
        LXI H,MSG
PRINT:  MOV A,M
        ORA A
        JZ RECEIVE
        CALL SEND
        INX H
        JMP PRINT
RECEIVE:IN 11H
        ANI 1
        JZ RECEIVE
        IN 10H
        PUSH PSW
        CMA
        OUT 0FFH
        POP PSW
        CALL SEND
        CPI 13
        JNZ RECEIVE
        MVI A,10
        CALL SEND
        JMP RECEIVE
SEND:   MOV B,A
WAITTX: IN 11H
        ANI 2
        JZ WAITTX
        MOV A,B
        OUT 10H
        RET
MSG: DB 'IMSAI 8080 TERMINAL READY',13,10,13,10
     DB 'TYPE SOMETHING AND PRESS ENTER.',13,10
     DB 'YOUR KEYS ALSO DRIVE THE OUTPUT LEDS.',13,10,13,10,'> ',0
