// SPDX-License-Identifier: MIT
// Altera-specific clock generation belongs only to the MiSTer adapter.
module imsai_clock(input wire refclk, input wire reset,
                   output wire clk, output wire locked);
    wire [17:0] clocks;
    altera_pll #(
        .fractional_vco_multiplier("false"),
        .reference_clock_frequency("50.0 MHz"),
        .operation_mode("direct"), .number_of_clocks(1),
        .output_clock_frequency0("50.0 MHz"),
        .phase_shift0("0 ps"), .duty_cycle0(50),
        .pll_type("General"), .pll_subtype("General")
    ) pll (
        .refclk(refclk), .rst(reset), .outclk(clocks),
        .locked(locked), .fboutclk(), .fbclk(1'b0)
    );
    assign clk = clocks[0];
endmodule
