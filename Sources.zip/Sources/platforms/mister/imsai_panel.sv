// SPDX-License-Identifier: MIT
// Monitor-style bus-master controls. RUN resumes the suspended CPU.
module imsai_panel(input wire clk,reset,input wire [10:0] key,
 input wire stopped,output reg stop_requested=0,
 output reg [15:0] panel_address=0,output reg [7:0] panel_data=0,
 output reg panel_deposit=0,output reg [1:0] edit_mode=0);
 reg toggle=0;
 reg [4:0] hex_digit;
 always @* begin
 case(key[7:0])
 8'h45:hex_digit=0;8'h16:hex_digit=1;8'h1e:hex_digit=2;
 8'h26:hex_digit=3;8'h25:hex_digit=4;8'h2e:hex_digit=5;
 8'h36:hex_digit=6;8'h3d:hex_digit=7;8'h3e:hex_digit=8;
 8'h46:hex_digit=9;8'h1c:hex_digit=10;8'h32:hex_digit=11;
 8'h21:hex_digit=12;8'h23:hex_digit=13;8'h24:hex_digit=14;
 8'h2b:hex_digit=15;default:hex_digit=16;
 endcase
 end
 always @(posedge clk) begin
 toggle<=key[10];panel_deposit<=0;
 if(reset) begin stop_requested<=0;panel_address<=0;panel_data<=0;edit_mode<=0;end
 else if(key[10]!=toggle && key[9] && !key[8]) begin
 if(key[7:0]==8'h05) begin // F1
 stop_requested<=!stop_requested;edit_mode<=0;
 end else if(stopped) begin
 case(key[7:0])
 8'h06:begin edit_mode<=1;panel_address<=0;end // F2, address entry
 8'h04:begin edit_mode<=2;panel_data<=0;end // F3, byte entry
 8'h0c:begin panel_deposit<=1;edit_mode<=0;end // F4
 8'h03:begin panel_address<=panel_address+1'b1;edit_mode<=0;end // F5
 8'h0b:begin panel_address<=panel_address-1'b1;edit_mode<=0;end // F6
 8'h5a,8'h76:edit_mode<=0; // Enter/Escape completes entry
 default:if(!hex_digit[4]) begin
 if(edit_mode==1) panel_address<={panel_address[11:0],hex_digit[3:0]};
 if(edit_mode==2) panel_data<={panel_data[3:0],hex_digit[3:0]};
 end
 endcase
 end
 end
 end
endmodule
