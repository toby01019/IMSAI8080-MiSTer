// SPDX-License-Identifier: MIT
// Static artwork plus live LEDs and switch positions. Two clocks of pixel latency.
module imsai_front_video(input wire clk,input wire [9:0] x,y,
 input wire [15:0] address_bits,switch_bits,
 input wire [7:0] data_bits,lamps,status_bits,input_bits,
 input wire inte,running,cpu_wait,cpu_hold,stopped,loaded,
 input wire [1:0] edit_mode,input wire deposit_active,reset_active,
 output reg [23:0] rgb);
 (* ramstyle = "M10K" *) reg [7:0] artwork[0:168959];
 reg [23:0] palette[0:255];
 initial begin
  $readmemh("panel_assets/panel.hex",artwork);
  $readmemh("panel_assets/palette.hex",palette);
 end
 wire inside_panel=x<640 && y>=96 && y<360;
 wire [17:0] row_offset={8'b0,y}-18'd96;
 wire [17:0] rom_address=inside_panel?((row_offset<<9)+(row_offset<<7)+{8'b0,x}):18'd0;
 reg [7:0] index_q;reg [23:0] base_color;
 reg [9:0] x_q=0,y_q=0,x_d=0,y_d=0;
 reg inside_q=0,inside_d=0;
 always @(posedge clk) begin
  index_q<=artwork[rom_address];base_color<=palette[index_q];
  x_q<=x;y_q<=y;x_d<=x_q;y_d<=y_q;
  inside_q<=inside_panel;inside_d<=inside_q;
 end
 function [7:0] hex_digit(input [3:0] n);hex_digit=(n<10?8'd48:8'd55)+n;endfunction
 reg [7:0] character;reg [2:0] column;reg [3:0] row;
 integer ci;
 wire text_pixel;
 imsai_font font(character,column,row,text_pixel);
 localparam [8*64-1:0] HELP="F1 RUN/STOP F2 ADDR F3 BYTE F4 WRITE F5+ F6- F7 RETURN          ";
 localparam [8*64-1:0] NOTE="STEP/POWER: DISPLAY ONLY  INPUT: F12 OR GAME KEYS 1-8           ";
 always @* begin
  character=32;column=0;row=0;ci=0;
  if(x_d>=64 && x_d<576) begin
   ci=(x_d-64)>>3;column=(x_d-64)%8;
   if(y_d>=388 && y_d<400) begin character=HELP[(63-ci)*8+:8];row=y_d-388;end
   if(y_d>=448 && y_d<460) begin character=NOTE[(63-ci)*8+:8];row=y_d-448;end
   if(y_d>=416 && y_d<428) begin
    row=y_d-416;
    case(ci)
    0:character="A";1:character="D";2:character="D";3:character="R";
    5:character=hex_digit(address_bits[15:12]);6:character=hex_digit(address_bits[11:8]);
    7:character=hex_digit(address_bits[7:4]);8:character=hex_digit(address_bits[3:0]);
    11:character="D";12:character="A";13:character="T";14:character="A";
    16:character=hex_digit(data_bits[7:4]);17:character=hex_digit(data_bits[3:0]);
    20:character="I";21:character="N";23:character=hex_digit(input_bits[7:4]);24:character=hex_digit(input_bits[3:0]);
    28:character=loaded?"L":"N";29:character=loaded?"O":"O";30:character=loaded?"A":" ";31:character=loaded?"D":"R";
    32:character=loaded?"E":"O";33:character=loaded?"D":"M";
    38:character=stopped?"S":"R";39:character=stopped?"T":"U";40:character=stopped?"O":"N";41:character=stopped?"P":" ";
    default:character=32;
    endcase
   end
  end
 end
 function [23:0] led(input [9:0] px,py,input integer cx,cy,input bit on,input [23:0] under);
  integer dx,dy,ax,ay;
  begin
   dx=$signed({1'b0,px})-cx;dy=$signed({1'b0,py})-cy;
   ax=dx<0?-dx:dx;ay=dy<0?-dy:dy;led=under;
   if(ax<=4 && ay<=4 && (ax<=2 || ay<=2)) begin
    if(on) begin
     if(ax<=1 && ay<=1) led=24'hfff0e0;
     else if(dx<=0 && dy<=0) led=24'hff7164;
     else led=24'hf52f43;
    end else if(ax<=2 && ay<=2) led=24'h5a1520;
    else led=24'h290b10;
   end
  end
 endfunction
 function [23:0] paddle(input [9:0] px,py,input integer sx,sy,input bit red,up,selected,input [23:0] under);
  integer dx,dy,lip;
  reg [23:0] body,light,dark;
  begin
   dx=$signed({1'b0,px})-sx;dy=$signed({1'b0,py})-sy;lip=up?12:25;paddle=under;
   body=red?24'hc72b32:24'h1258b6;light=red?24'hf25052:24'h3988ee;dark=red?24'h70151c:24'h0a2c65;
   if(dx>=0 && dx<19 && dy>=0 && dy<36) begin
    paddle=body;
    if(dy<2 || dx<2) paddle=light;
    if(dx>=17 || dy>=34) paddle=dark;
    if(dy>=lip && dy<lip+3) paddle=light;
    if((up && dy>=lip+3)||(!up && dy<lip)) paddle=dark;
    if(selected && (dx==0 || dx==18 || dy==0 || dy==35)) paddle=24'h6cc8e8;
   end
  end
 endfunction
 always @* begin
  rgb=inside_d?base_color:24'h101418;
  if(inside_d)begin
  rgb=led(x_d,y_d,52,132,lamps[7],rgb);
  rgb=led(x_d,y_d,76,132,lamps[6],rgb);
  rgb=led(x_d,y_d,100,132,lamps[5],rgb);
  rgb=led(x_d,y_d,124,132,lamps[4],rgb);
  rgb=led(x_d,y_d,147,132,lamps[3],rgb);
  rgb=led(x_d,y_d,170,132,lamps[2],rgb);
  rgb=led(x_d,y_d,193,132,lamps[1],rgb);
  rgb=led(x_d,y_d,216,132,lamps[0],rgb);
  rgb=led(x_d,y_d,52,175,status_bits[7],rgb);
  rgb=led(x_d,y_d,76,175,status_bits[6],rgb);
  rgb=led(x_d,y_d,100,175,status_bits[5],rgb);
  rgb=led(x_d,y_d,124,175,status_bits[4],rgb);
  rgb=led(x_d,y_d,147,175,status_bits[3],rgb);
  rgb=led(x_d,y_d,170,175,status_bits[2],rgb);
  rgb=led(x_d,y_d,193,175,status_bits[1],rgb);
  rgb=led(x_d,y_d,216,175,status_bits[0],rgb);
  rgb=led(x_d,y_d,266,175,data_bits[7],rgb);
  rgb=led(x_d,y_d,289,175,data_bits[6],rgb);
  rgb=led(x_d,y_d,313,175,data_bits[5],rgb);
  rgb=led(x_d,y_d,336,175,data_bits[4],rgb);
  rgb=led(x_d,y_d,359,175,data_bits[3],rgb);
  rgb=led(x_d,y_d,382,175,data_bits[2],rgb);
  rgb=led(x_d,y_d,405,175,data_bits[1],rgb);
  rgb=led(x_d,y_d,429,175,data_bits[0],rgb);
  rgb=led(x_d,y_d,52,218,address_bits[15],rgb);
  rgb=led(x_d,y_d,76,218,address_bits[14],rgb);
  rgb=led(x_d,y_d,100,218,address_bits[13],rgb);
  rgb=led(x_d,y_d,124,218,address_bits[12],rgb);
  rgb=led(x_d,y_d,147,218,address_bits[11],rgb);
  rgb=led(x_d,y_d,170,218,address_bits[10],rgb);
  rgb=led(x_d,y_d,193,218,address_bits[9],rgb);
  rgb=led(x_d,y_d,216,218,address_bits[8],rgb);
  rgb=led(x_d,y_d,266,218,address_bits[7],rgb);
  rgb=led(x_d,y_d,289,218,address_bits[6],rgb);
  rgb=led(x_d,y_d,313,218,address_bits[5],rgb);
  rgb=led(x_d,y_d,336,218,address_bits[4],rgb);
  rgb=led(x_d,y_d,359,218,address_bits[3],rgb);
  rgb=led(x_d,y_d,382,218,address_bits[2],rgb);
  rgb=led(x_d,y_d,405,218,address_bits[1],rgb);
  rgb=led(x_d,y_d,429,218,address_bits[0],rgb);
  rgb=led(x_d,y_d,479,213,inte,rgb);
  rgb=led(x_d,y_d,523,213,running,rgb);
  rgb=led(x_d,y_d,555,213,cpu_wait,rgb);
  rgb=led(x_d,y_d,588,213,cpu_hold,rgb);
  rgb=paddle(x_d,y_d,39,262,1'b0,switch_bits[15],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,62,262,1'b0,switch_bits[14],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,86,262,1'b0,switch_bits[13],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,110,262,1'b0,switch_bits[12],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,134,262,1'b1,switch_bits[11],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,158,262,1'b1,switch_bits[10],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,182,262,1'b1,switch_bits[9],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,206,262,1'b1,switch_bits[8],edit_mode==1,rgb);
  rgb=paddle(x_d,y_d,254,262,1'b0,switch_bits[7],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,278,262,1'b0,switch_bits[6],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,301,262,1'b0,switch_bits[5],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,325,262,1'b0,switch_bits[4],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,348,262,1'b1,switch_bits[3],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,371,262,1'b1,switch_bits[2],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,395,262,1'b1,switch_bits[1],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,419,262,1'b1,switch_bits[0],edit_mode!=0,rgb);
  rgb=paddle(x_d,y_d,460,262,1'b1,edit_mode==1,1'b0,rgb);
  rgb=paddle(x_d,y_d,485,262,1'b1,deposit_active,1'b0,rgb);
  rgb=paddle(x_d,y_d,509,262,1'b0,reset_active,1'b0,rgb);
  rgb=paddle(x_d,y_d,534,262,1'b1,!stopped,1'b0,rgb);
  rgb=paddle(x_d,y_d,558,262,1'b0,1'b0,1'b0,rgb);
  rgb=paddle(x_d,y_d,583,262,1'b1,loaded,1'b0,rgb);
  end
  if(text_pixel) rgb=24'hd0d9df;
  if(x_d>=640 || y_d>=480) rgb=0;
 end
endmodule
