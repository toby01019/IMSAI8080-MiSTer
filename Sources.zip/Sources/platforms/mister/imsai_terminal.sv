// SPDX-License-Identifier: MIT
// 80x16 ASCII terminal, circular scroll buffer and synchronous display read.
module imsai_terminal(input wire clk,reset,input wire tx_write,
 input wire [7:0] tx_data,input wire [9:0] x,y,
 output wire ready,output wire text_pixel);
 reg [7:0] cells[0:2047];
 reg [6:0] col=0;
 reg [3:0] line=0,top=0;
 reg clearing=1,clear_all=1;
 reg [10:0] clear_at=0;
 reg previous_reset=0;
 reg [7:0] character;
 wire in_window = x>=64 && x<544 && y>=64 && y<256;
 wire [9:0] local_y=y-10'd64;
 wire [9:0] local_x=x-10'd64;
 wire [3:0] screen_row=local_y/10'd12;
 wire [3:0] memory_row=screen_row+top;
 wire [3:0] write_row=top+line;
 wire [6:0] screen_col=local_x/6;
 wire [10:0] read_at={memory_row,screen_col};
 wire [2:0] glyph_x=local_x%6;
 wire [3:0] glyph_y=local_y%10'd12;
 wire glyph;
 imsai_font font(character,glyph_x,glyph_y,glyph);
 assign text_pixel=in_window && glyph;
 assign ready=!clearing && !reset;
 task newline;
 begin
 col<=0;
 if(line==15) begin
 top<=top+1'b1;
 clearing<=1;clear_all<=0;clear_at<={top,7'b0};
 end else line<=line+1'b1;
 end
 endtask
 always @(posedge clk) begin
 character<=cells[read_at];
 previous_reset<=reset;
 if(reset && !previous_reset) begin
 col<=0;line<=0;top<=0;clearing<=1;clear_all<=1;clear_at<=0;
 end else if(clearing) begin
 cells[clear_at]<=8'd32;
 clear_at<=clear_at+1'b1;
 if((clear_all && clear_at==2047)||(!clear_all && clear_at[6:0]==127)) clearing<=0;
 end else if(tx_write) begin
 if(tx_data==13) col<=0;
 else if(tx_data==10) newline();
 else if(tx_data==8) begin
 if(col!=0) begin col<=col-1'b1;cells[{write_row,col}-1'b1]<=32;end
 end else if(tx_data>=32 && tx_data<127) begin
 cells[{write_row,col}]<=tx_data;
 if(col==79) newline(); else col<=col+1'b1;
 end
 end
 end
endmodule

