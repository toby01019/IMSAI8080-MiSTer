// SPDX-License-Identifier: MIT
// Keyboard keys 1..8 operate the latched input switches, left to right.
module imsai_game_switches(input wire clk,reset,enabled,
 input wire [10:0] key,output reg [7:0] switches=8'h02);
 reg toggle=0;reg [7:0] held=0;reg [7:0] mask;
 always @* begin
 case(key[7:0])
 8'h16:mask=8'h80;8'h1e:mask=8'h40;8'h26:mask=8'h20;8'h25:mask=8'h10;
 8'h2e:mask=8'h08;8'h36:mask=8'h04;8'h3d:mask=8'h02;8'h3e:mask=8'h01;
 default:mask=0;
 endcase
 end
 always @(posedge clk) begin
 toggle<=key[10];
 if(reset) begin switches<=8'h02;held<=0;end
 else if(key[10]!=toggle && !key[8]) begin
 if(!key[9]) held<=held & ~mask;
 else begin
 held<=held | mask;
 if(enabled && !(|(held & mask))) switches<=switches ^ mask;
 end
 end
 end
endmodule
