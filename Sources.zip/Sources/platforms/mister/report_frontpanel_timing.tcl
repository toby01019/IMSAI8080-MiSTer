project_open IMSAI8080
create_timing_netlist
read_sdc
update_timing_netlist
report_clock_fmax_summary -file output_files/frontpanel_fmax.rpt
report_timing -setup -npaths 20 -detail full_path -file output_files/frontpanel_setup.rpt
report_timing -hold -npaths 20 -detail full_path -file output_files/frontpanel_hold.rpt
set panel_regs [get_registers {*front_graphics*}]
post_message "FRONTPANEL_REGISTERS [get_collection_size $panel_regs]"
if {[get_collection_size $panel_regs] > 0} {
 report_timing -setup -to $panel_regs -npaths 10 -detail full_path -file output_files/frontpanel_to_setup.rpt
 report_timing -setup -from $panel_regs -npaths 10 -detail full_path -file output_files/frontpanel_from_setup.rpt
 report_timing -hold -to $panel_regs -npaths 10 -detail full_path -file output_files/frontpanel_to_hold.rpt
 report_timing -hold -from $panel_regs -npaths 10 -detail full_path -file output_files/frontpanel_from_hold.rpt
}
project_close

