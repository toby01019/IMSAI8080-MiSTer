derive_pll_clocks
derive_clock_uncertainty

# Match the MiSTer framework's clock-domain separation for our differently
# named core PLL. The framework switches video clock/data together and handles
# transfers to its other domains. Do not exclude paths within the core clock.
set_clock_groups -exclusive \
    -group [get_clocks {*clock_source*}] \
    -group [get_clocks {pll_hdmi*}] \
    -group [get_clocks {pll_audio*}] \
    -group [get_clocks {*h2f_user0_clk}] \
    -group [get_clocks {spi_sck}] \
    -group [get_clocks {hdmi_sck}] \
    -group [get_clocks {FPGA_CLK1_50}] \
    -group [get_clocks {FPGA_CLK2_50}] \
    -group [get_clocks {FPGA_CLK3_50}]
