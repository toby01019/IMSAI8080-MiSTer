// SPDX-License-Identifier: MIT
// F7 selects the new frontplate without changing emulation or terminal state.
// The choice becomes active only during vertical blank, avoiding split frames.
module imsai_view_select(input wire clk,reset,loaded,game_mode,frame_end,
 input wire [10:0] key,output reg front_view=0);
 reg requested=0,previous_toggle=0;
 always @(posedge clk) begin
  previous_toggle<=key[10];
  if(reset) begin requested<=0;front_view<=0;end
  else begin
   if(key[10]!=previous_toggle && key[9] && !key[8] && key[7:0]==8'h83)
    requested<=!requested;
   if(frame_end)front_view<=requested;
  end
 end
endmodule
