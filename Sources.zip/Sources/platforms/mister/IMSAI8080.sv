// SPDX-License-Identifier: GPL-2.0-or-later
// MiSTer adapter using the MiSTer-devel/Template_MiSTer port interface.
module emu (
    `include "sys/emu_ports.vh"
);
    wire clk_system, clock_locked;
    imsai_clock clock_source(.refclk(CLK_50M), .reset(RESET),
        .clk(clk_system), .locked(clock_locked));
    reg [1:0] reset_pipe = 2'b11;
    always @(posedge clk_system or negedge clock_locked)
        if (!clock_locked) reset_pipe <= 2'b11;
        else reset_pipe <= {reset_pipe[0], 1'b0};
    assign ADC_BUS = 'z;
    assign USER_OUT = '1;
    assign {UART_RTS, UART_TXD, UART_DTR} = 3'b110;
    assign {SD_SCK, SD_MOSI, SD_CS} = 'z;
    assign {SDRAM_DQ, SDRAM_A, SDRAM_BA, SDRAM_CLK, SDRAM_CKE,
        SDRAM_DQML, SDRAM_DQMH, SDRAM_nWE, SDRAM_nCAS, SDRAM_nRAS, SDRAM_nCS} = 'z;
    assign {DDRAM_CLK, DDRAM_BURSTCNT, DDRAM_ADDR, DDRAM_DIN,
        DDRAM_BE, DDRAM_RD, DDRAM_WE} = '0;
    assign VGA_SL = 0;
    assign VGA_F1 = 0;
    assign VGA_SCALER = 0;
    assign VGA_DISABLE = 0;
    assign HDMI_FREEZE = 0;
    assign HDMI_BLACKOUT = 0;
    assign HDMI_BOB_DEINT = 0;
    assign {AUDIO_S, AUDIO_L, AUDIO_R, AUDIO_MIX} = '0;
    assign LED_DISK = 0;
    assign LED_POWER = 0;
    assign BUTTONS = 0;
    assign VIDEO_ARX = 4;
    assign VIDEO_ARY = 3;

    localparam CONF_STR = {
        "IMSAI8080;;",
        "F0,BIN,Load program at 0000;",
        "F1,BIN,Load original LED game;",
        "O[2],Input bit 0,0,1;", "O[3],Input bit 1,0,1;",
        "O[4],Input bit 2,0,1;", "O[5],Input bit 3,0,1;",
        "O[6],Input bit 4,0,1;", "O[7],Input bit 5,0,1;",
        "O[8],Input bit 6,0,1;", "O[9],Input bit 7,0,1;",
        "T[0],Reset;", "v,0;", "V,Photo front panel 0.5;"
    };
    wire [10:0] keyboard_event;
    wire [127:0] options;
    wire [1:0] buttons;
    wire download, download_write;
    wire [26:0] download_address;
    wire [7:0] download_data;
    wire [15:0] download_index;
    reg game_mode=0;
    hps_io #(.CONF_STR(CONF_STR)) hps_io (
        .clk_sys(clk_system), .HPS_BUS(HPS_BUS),
        .status(options), .buttons(buttons), .ps2_key(keyboard_event),
        .status_in(128'b0), .status_set(1'b0), .status_menumask(16'b0),
        .ioctl_download(download), .ioctl_wr(download_write),
        .ioctl_index(download_index),.ioctl_addr(download_address), .ioctl_dout(download_data),
        .ioctl_wait(1'b0), .ioctl_upload_req(1'b0),
        .ioctl_upload_index(8'b0), .ioctl_din(8'b0)
    );
    reg loaded = 0, previous_download = 0, overflow = 0;
    always @(posedge clk_system) begin
        previous_download <= download;
        if(RESET) game_mode<=0;
        else if(download) game_mode<=download_index[7:0]==1;
        if (RESET) begin loaded <= 0; overflow <= 0; end
        else if (download) begin
            loaded <= 0;
            if (!previous_download) overflow <= 0;
            else if (download_write && |download_address[26:16]) overflow <= 1;
        end else if (previous_download) loaded <= !overflow;
    end
    wire [7:0] game_switches;
    wire [7:0] switches=game_mode?game_switches:options[9:2];
    imsai_game_switches game_inputs(.clk(clk_system),
        .reset(RESET || (download && !previous_download)),
        .enabled(game_mode && loaded && !stop_requested),
        .key(keyboard_event),.switches(game_switches));
    wire [7:0] lamps, bus_data, cpu_status;
    wire [15:0] address;
    wire halted;
    wire interrupts_enabled,cpu_wait,cpu_hold;
    wire stop_requested,stopped,panel_deposit;
    wire [15:0] panel_address;
    wire [7:0] panel_data,panel_read_data;
    wire [1:0] edit_mode;
    imsai_panel panel(.clk(clk_system),.reset(machine_reset),
        .key(keyboard_event),.stopped(stopped),.stop_requested(stop_requested),
        .panel_address(panel_address),.panel_data(panel_data),
        .panel_deposit(panel_deposit),.edit_mode(edit_mode));
    wire [7:0] rx_data,tx_data;
    wire rx_valid,rx_read,tx_write,tx_ready;
    imsai_keyboard keyboard(.clk(clk_system),.reset(machine_reset),
        .key(keyboard_event),.enabled(!stop_requested && !game_mode),.read_byte(rx_read),.data(rx_data),.valid(rx_valid));
    wire machine_reset = reset_pipe[1] | RESET | options[0] | buttons[1] | download | !loaded;
    imsai_machine machine (
        .clk(clk_system), .reset(machine_reset), .switches(switches), .lamps(lamps),
        .loader_write(download && download_write && !(|download_address[26:16])),
        .loader_address(download_address[15:0]), .loader_data(download_data),
        .address(address), .bus_data(bus_data), .status(cpu_status), .halted(halted),
        .interrupts_enabled(interrupts_enabled),.cpu_wait(cpu_wait),.cpu_hold(cpu_hold),
        .terminal_rx_data(rx_data),.terminal_rx_valid(rx_valid),
        .terminal_rx_read(rx_read),.terminal_tx_write(tx_write),
        .terminal_tx_data(tx_data),.terminal_tx_ready(tx_ready),
        .stop_requested(stop_requested),.stopped(stopped),
        .panel_address(panel_address),.panel_data(panel_data),
        .panel_deposit(panel_deposit),.panel_read_data(panel_read_data)
    );
    assign LED_USER = loaded && !halted && !stopped;

    // 640x480 raster: terminal and scaled original-style panel share one screen.
    reg pixel_enable=0;reg [9:0] x=0,y=0;
    reg [9:0] scaled_x=0,scaled_y=96;reg [1:0] scale_phase_x=0,scale_phase_y=0;
    always @(posedge clk_system) begin
      pixel_enable<=!pixel_enable;
      if(pixel_enable) begin
        if(x==799)begin
          x<=0;scaled_x<=0;scale_phase_x<=0;
          if(y==524)begin y<=0;scaled_y<=96;scale_phase_y<=0;end
          else begin
            y<=y+1'b1;
            if(y>=250 && y<448)begin
              scaled_y<=scaled_y+(scale_phase_y==2?2:1);
              scale_phase_y<=scale_phase_y==2?0:scale_phase_y+1'b1;
            end
          end
        end else begin
          x<=x+1'b1;
          if(x>=80 && x<560)begin
            scaled_x<=scaled_x+(scale_phase_x==2?2:1);
            scale_phase_x<=scale_phase_x==2?0:scale_phase_x+1'b1;
          end
        end
      end
    end
    assign CLK_VIDEO=clk_system;assign CE_PIXEL=pixel_enable;
    wire raw_hs=!(x>=656 && x<752),raw_vs=!(y>=490 && y<492),raw_de=x<640 && y<480;
    wire [9:0] term_x=x>=80 && x<560?x-10'd16:10'd1023;
    wire [9:0] term_y=y>=8 && y<200?y+10'd56:10'd511;
    wire terminal_pixel;
    imsai_terminal terminal(.clk(clk_system),.reset(machine_reset),
      .tx_write(tx_write),.tx_data(tx_data),.x(term_x),.y(term_y),
      .ready(tx_ready),.text_pixel(terminal_pixel));

    reg [15:0] shown_address=0,shown_panel_switches=0;
    reg [7:0] shown_data=0,shown_lamps=0,shown_switches=0,shown_status=0;
    reg shown_inte=0,shown_wait=0,shown_hold=0,shown_running=0,shown_stopped=0,shown_loaded=0;
    reg [1:0] shown_edit=0;
    reg [21:0] deposit_flash=0,reset_flash=0;
    always @(posedge clk_system) begin
      if(panel_deposit)deposit_flash<=3000000;else if(deposit_flash!=0)deposit_flash<=deposit_flash-1'b1;
      if(machine_reset)reset_flash<=3000000;else if(reset_flash!=0)reset_flash<=reset_flash-1'b1;
    end
    reg shown_deposit=0,shown_reset=0;
    always @(posedge clk_system)if(pixel_enable && x==0 && y==480)begin
      shown_address<=stopped?panel_address:address;shown_data<=stopped?panel_read_data:bus_data;
      shown_lamps<=lamps;shown_switches<=switches;shown_status<=cpu_status;
      shown_panel_switches<=stopped?(edit_mode==2?{panel_address[15:8],panel_data}:panel_address):{8'b0,switches};
      shown_inte<=interrupts_enabled;shown_wait<=cpu_wait;shown_hold<=cpu_hold;
      shown_running<=loaded && !halted && !stopped;shown_stopped<=stopped;shown_loaded<=loaded;shown_edit<=edit_mode;
      shown_deposit<=deposit_flash!=0;shown_reset<=reset_flash!=0;
    end
    wire front_view;
    imsai_view_select view_control(.clk(clk_system),.reset(reset_pipe[1] | RESET | options[0] | buttons[1]),.loaded(loaded),
      .game_mode(game_mode),.frame_end(pixel_enable && x==0 && y==480),
      .key(keyboard_event),.front_view(front_view));
    wire combined_panel=x>=80 && x<560 && y>=250 && y<448;
    wire [9:0] front_x=front_view?x:(combined_panel?scaled_x:10'd1023);
    wire [9:0] front_y=front_view?y:(combined_panel?scaled_y:10'd511);
    wire [23:0] front_rgb;
    imsai_front_video front_graphics(.clk(clk_system),.x(front_x),.y(front_y),
      .address_bits(shown_address),.switch_bits(shown_panel_switches),.input_bits(shown_switches),
      .data_bits(shown_data),.lamps(shown_lamps),.status_bits(shown_status),
      .inte(shown_inte),.running(shown_running),.cpu_wait(shown_wait),.cpu_hold(shown_hold),
      .stopped(shown_stopped),.loaded(shown_loaded),.edit_mode(shown_edit),
      .deposit_active(shown_deposit),.reset_active(shown_reset),.rgb(front_rgb));
    localparam [8*64-1:0] HELP="F1 RUN/STOP F2 ADDR F3 BYTE F4 WRITE F5+ F6- F7 ZOOM            ";
    localparam [8*64-1:0] LIMITS="STEP/POWER: DISPLAY ONLY  INPUT: F12 OR GAME KEYS 1-8           ";
    reg [7:0] label_char;reg [2:0] label_col;reg [3:0] label_row;integer ci;
    wire label_pixel;
    imsai_font labels(label_char,label_col,label_row,label_pixel);
    function [7:0] hex_char(input [3:0] n);hex_char=(n<10?8'd48:8'd55)+n;endfunction
    always @* begin
      label_char=32;label_col=0;label_row=0;ci=0;
      if(x>=64 && x<576)begin
        ci=(x-64)>>3;label_col=(x-64)%8;
        if(y>=464 && y<476)begin label_char=HELP[(63-ci)*8+:8];label_row=y-464;end
        if(y>=232 && y<244)begin label_char=LIMITS[(63-ci)*8+:8];label_row=y-232;end
        if(y>=208 && y<220)begin
          label_row=y-208;
          case(ci)
          0:label_char="M";1:label_char="E";2:label_char="M";
          4:label_char=hex_char(shown_address[15:12]);5:label_char=hex_char(shown_address[11:8]);
          6:label_char=hex_char(shown_address[7:4]);7:label_char=hex_char(shown_address[3:0]);
          9:label_char="=";11:label_char=hex_char(shown_data[7:4]);12:label_char=hex_char(shown_data[3:0]);
          16:label_char="W";17:label_char="R";18:label_char="I";19:label_char="T";20:label_char="E";
          22:label_char=hex_char(panel_data[7:4]);23:label_char=hex_char(panel_data[3:0]);
          27:label_char="I";28:label_char="N";30:label_char=hex_char(shown_switches[7:4]);31:label_char=hex_char(shown_switches[3:0]);
          36:label_char=loaded?"L":"N";37:label_char=loaded?"O":"O";38:label_char=loaded?"A":" ";39:label_char=loaded?"D":"R";
          40:label_char=loaded?"E":"O";41:label_char=loaded?"D":"M";
          46:label_char=stopped?"S":"R";47:label_char=stopped?"T":"U";48:label_char=stopped?"O":"N";49:label_char=stopped?"P":" ";
          default:label_char=32;
          endcase
        end
      end
    end
    reg [23:0] upper_color;
    always @* begin
      upper_color=24'h101418;
      if(x>=72 && x<568 && y<202)upper_color=24'h22343c;
      if(x>=80 && x<560 && y>=8 && y<200)upper_color=24'h081510;
      if(terminal_pixel)upper_color=24'h7ee8a0;
      if(label_pixel)upper_color=24'hd0d9df;
      if(!raw_de)upper_color=0;
    end
    reg [23:0] upper_q=0,upper_d=0;
    reg [1:0] hs_pipe=3,vs_pipe=3,de_pipe=0,panel_pipe=0;
    always @(posedge clk_system)begin
      upper_q<=upper_color;upper_d<=upper_q;
      hs_pipe<={hs_pipe[0],raw_hs};vs_pipe<={vs_pipe[0],raw_vs};de_pipe<={de_pipe[0],raw_de};
      panel_pipe<={panel_pipe[0],combined_panel};
    end
    assign VGA_HS=hs_pipe[1];assign VGA_VS=vs_pipe[1];assign VGA_DE=de_pipe[1];
    assign {VGA_R,VGA_G,VGA_B}=de_pipe[1]?((front_view||panel_pipe[1])?front_rgb:upper_d):24'b0;
endmodule
