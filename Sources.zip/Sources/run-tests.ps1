param([string]$SimulatorDirectory = (Join-Path $PSScriptRoot '..\08_Werkzeuge\Icarus\bin'))
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $SimulatorDirectory 'iverilog.exe'
$runtime = Join-Path $SimulatorDirectory 'vvp.exe'
if (!(Test-Path $compiler) -or !(Test-Path $runtime)) {
    throw 'Icarus Verilog fehlt. SimulatorDirectory auf dessen bin-Verzeichnis setzen.'
}
$buildDirectory = Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Force $buildDirectory | Out-Null
$simulation = Join-Path $buildDirectory 'machine.vvp'
& $compiler -g2012 -s tb_machine -o $simulation `
    (Join-Path $PSScriptRoot 'third_party\vm80a.v') `
    (Join-Path $PSScriptRoot 'rtl\imsai_machine.sv') `
    (Join-Path $PSScriptRoot 'tests\tb_machine.sv')
if ($LASTEXITCODE -ne 0) { throw 'Hardwarebeschreibung konnte nicht kompiliert werden.' }
& $runtime $simulation
if ($LASTEXITCODE -ne 0) { throw 'Funktionstest fehlgeschlagen.' }

$platformDirectory = Join-Path $PSScriptRoot 'platforms/mister'
foreach ($test in @('terminal','keyboard','demo','panel','hold','original_game','game_switches','basic')) {
    $testOutput = Join-Path $buildDirectory ($test + '.vvp')
    & $compiler -g2012 -s ('tb_' + $test) -o $testOutput `
        (Join-Path $PSScriptRoot 'third_party/vm80a.v') `
        (Join-Path $PSScriptRoot 'rtl/imsai_machine.sv') `
        (Join-Path $platformDirectory 'imsai_font.sv') `
        (Join-Path $platformDirectory 'imsai_terminal.sv') `
        (Join-Path $platformDirectory 'imsai_keyboard.sv') `
        (Join-Path $platformDirectory 'imsai_panel.sv') `
        (Join-Path $platformDirectory 'imsai_game_switches.sv') `
        (Join-Path $PSScriptRoot ('tests/tb_' + $test + '.sv'))
    if ($LASTEXITCODE -ne 0) { throw "Compilation failed: $test" }
    & $runtime $testOutput ("+ROM=" + (Join-Path $PSScriptRoot 'tests/terminal-demo.hex')) ("+GAME=" + (Join-Path $PSScriptRoot 'tests/kill-the-lights.hex')) ("+BASIC=" + (Join-Path $PSScriptRoot 'tests/tinybasic-v3.hex'))
    if ($LASTEXITCODE -ne 0) { throw "Simulation failed: $test" }
}
