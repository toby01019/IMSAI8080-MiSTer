# Build sources � 23 October 2026

These are the sources used for the hardware-tested front-panel update.
Build `platforms/mister/IMSAI8080.qpf` with Quartus Prime Lite 25.1.
Keep the working directory at `platforms/mister` so the panel ROM files resolve.
Existing component licenses remain in their files. Our own parts use LICENSE.

The renderer uses an AI-generated illustration based on Toby's reference photo;
the active LEDs and switches are drawn by HDL. STEP and POWER are display-only.
Historical Microsoft/MITS BASIC binaries and derived RAM images are omitted.
The extended BASIC tests need separately supplied local runtime images.
