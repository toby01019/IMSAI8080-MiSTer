// SPDX-License-Identifier: MIT
// Platform-independent IMSAI prototype. All inputs synchronous to clk.
module imsai_machine #(
    parameter integer CLOCKS_PER_CPU = 25
)(
    input wire clk, reset,
    input wire [7:0] switches,
    input wire stop_requested,
    input wire [15:0] panel_address,
    input wire [7:0] panel_data,
    input wire panel_deposit,
    output wire stopped,
    output wire [7:0] panel_read_data,
    output wire [7:0] lamps,
    input wire loader_write,
    input wire [15:0] loader_address,
    input wire [7:0] loader_data,
    output wire [15:0] address,
    output wire [7:0] bus_data,
    output wire [7:0] status,
    input wire [7:0] terminal_rx_data,
    input wire terminal_rx_valid, terminal_tx_ready,
    output reg terminal_rx_read = 0,
    output reg terminal_tx_write = 0,
    output reg [7:0] terminal_tx_data = 0,
    output wire halted,
    output wire interrupts_enabled,cpu_wait,cpu_hold
);
    reg [7:0] ram [0:65535];
    reg [7:0] memory_data;
    reg [7:0] held_memory_data;
    reg [7:0] status_latch = 0;
    reg [7:0] output_latch = 8'hff;
    reg previous_write_n = 1;
    reg previous_dbin = 0;
    reg [$clog2(CLOCKS_PER_CPU)-1:0] phase = 0;
    reg cpu_paused=0;
    reg [1:0] resume_delay=0;
    wire f1 = !cpu_paused && phase == 0;
    wire f2 = !cpu_paused && phase == CLOCKS_PER_CPU / 2;
    wire sync, dbin, write_n;
    wire [7:0] cpu_out;
    wire [7:0] cpu_in = status_latch[6]
        ? ((address[7:0] == 8'hff) ? switches :
           (address[7:0] == 8'h10) ? terminal_rx_data :
           (address[7:0] == 8'h11) ? {6'b0,terminal_tx_ready,terminal_rx_valid} : 8'hff)
        : (cpu_paused ? held_memory_data : memory_data);

    // Use the separate data ports rather than FPGA-internal tri-state buses.
    vm80a_core cpu (
        .pin_clk(clk), .pin_f1(f1), .pin_f2(f2), .pin_reset(reset),
        .pin_a(address), .pin_dout(cpu_out), .pin_din(cpu_in),
        .pin_aena(), .pin_dena(), .pin_hold(1'b0), .pin_hlda(cpu_hold),
        .pin_ready(1'b1), .pin_wait(cpu_wait), .pin_int(1'b0), .pin_inte(interrupts_enabled),
        .pin_sync(sync), .pin_dbin(dbin), .pin_wr_n(write_n)
    );

    // Stop between phase pulses. CPU state and read data remain stable.
    // On RUN restore the RAM read port for three clocks before resuming phases.
    assign stopped = cpu_paused && stop_requested && !reset;
    assign panel_read_data = memory_data;
    assign lamps = ~output_latch; // IMSAI programmed-output lamps are inverted.
    assign status = status_latch;
    assign halted = status_latch[3];
    assign bus_data = dbin ? cpu_in : cpu_out;

    // One write port shared by CPU and loader, plus one synchronous read port.
    // This form infers portable block RAM rather than a multi-write array.
    wire cpu_memory_write = !reset && !cpu_paused && previous_write_n && !write_n && !status_latch[4];
    wire load_memory_write = reset && loader_write;
    wire panel_memory_write = stopped && panel_deposit && !reset;
    wire [15:0] memory_write_address = load_memory_write ? loader_address :
        panel_memory_write ? panel_address : address;
    wire [7:0] memory_write_data = load_memory_write ? loader_data :
        panel_memory_write ? panel_data : cpu_out;
    always @(posedge clk) begin
        memory_data <= ram[stopped ? panel_address : address];
        if (!cpu_paused) held_memory_data <= memory_data;
        if (cpu_memory_write || load_memory_write || panel_memory_write)
            ram[memory_write_address] <= memory_write_data;
    end

    always @(posedge clk) begin
        if (!cpu_paused) begin
            if (phase == CLOCKS_PER_CPU - 1) phase <= '0;
            else phase <= phase + 1'b1;
        end
        if(reset) begin cpu_paused<=0;resume_delay<=0;end
        else if(!cpu_paused) begin
            resume_delay<=0;
            if(stop_requested && phase==CLOCKS_PER_CPU-1) cpu_paused<=1;
        end else if(stop_requested) resume_delay<=0;
        else if(resume_delay==3) begin cpu_paused<=0;resume_delay<=0;end
        else resume_delay<=resume_delay+1'b1;
        previous_write_n <= write_n;
        terminal_tx_write <= 0;
        terminal_rx_read <= 0;
        previous_dbin <= dbin;
        if (!reset && previous_dbin && !dbin && status_latch[6] && address[7:0] == 8'h10)
            terminal_rx_read <= 1;
        if (reset) begin
            status_latch <= 0;
            output_latch <= 8'hff;
        end else begin
            if (sync) status_latch <= cpu_out;
            if (previous_write_n && !write_n) begin
                if (status_latch[4]) begin
                    if (address[7:0] == 8'hff) output_latch <= cpu_out;
                    if (address[7:0] == 8'h10) begin
                        terminal_tx_data <= cpu_out; terminal_tx_write <= 1;
                    end
                end
            end
        end
    end
endmodule
